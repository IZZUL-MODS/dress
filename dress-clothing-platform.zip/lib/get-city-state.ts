import { Country, State, City } from "country-state-city"

interface CityState {
  city: string
  state: string
}

/**
 * Get a random valid city-state pair for a given country code.
 * Uses comprehensive geographic database (country-state-city).
 * Falls back gracefully for countries without detailed state data.
 */
export function getRandomCityState(countryCode: string): CityState | null {
  try {
    // Find country in database
    const countryObj = Country.getCountryByCode(countryCode)
    if (!countryObj) {
      return null
    }

    // Get all states for this country
    const states = State.getStatesOfCountry(countryCode)
    if (!states || states.length === 0) {
      return null
    }

    // Shuffle states and try to find one with valid cities
    // This improves UX for countries with many empty-city states
    const shuffledStates = [...states].sort(() => Math.random() - 0.5)
    
    // First pass: find states with cities different from state names
    for (const state of shuffledStates) {
      const cities = City.getCitiesOfState(countryCode, state.isoCode)
      
      if (cities && cities.length > 0) {
        // Prefer cities that are different from state name
        const differentCities = cities.filter(c => c.name !== state.name)
        
        if (differentCities.length > 0) {
          // Pick from cities that have different names than the state
          const randomCity = 
            differentCities[Math.floor(Math.random() * differentCities.length)]
          return {
            city: randomCity.name,
            state: state.name,
          }
        }
      }
    }
    
    // Second pass: if no different-name cities found, try again with any cities
    for (const state of shuffledStates) {
      const cities = City.getCitiesOfState(countryCode, state.isoCode)
      if (cities && cities.length > 0) {
        const randomCity = cities[Math.floor(Math.random() * cities.length)]
        return {
          city: randomCity.name,
          state: state.name,
        }
      }
    }

    // Fallback: If all states have no cities, use state name as city
    // This only happens for very small countries/territories with minimal data
    const randomState = states[Math.floor(Math.random() * states.length)]
    return {
      city: randomState.name,
      state: randomState.name,
    }
  } catch (error) {
    console.error(
      `Error getting city-state for ${countryCode}:`,
      error,
    )
    return null
  }
}
