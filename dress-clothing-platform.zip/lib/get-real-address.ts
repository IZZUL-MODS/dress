import { Country, State, City } from "country-state-city"

export interface RealAddress {
  street: string
  city: string
  state: string
  zipCode: string
}

/* ────────────────────────────────────────────────────────────────
 * Authentic address resolver.
 *
 * We ask the OpenStreetMap Overpass API for real objects that carry
 * an `addr:street` tag inside a bounding box around a genuine locality
 * in the requested country. Because these objects are real mapped
 * buildings/addresses, the street (and, when present, house number,
 * city, and postcode) are all authentic values that belong together.
 *
 * Nothing is invented: no random house numbers, no city-name-as-street
 * fallback, no Faker. If Overpass returns an object we use its own
 * tags; state/city gaps are filled only from the same OSM object's
 * tags, never fabricated.
 * ──────────────────────────────────────────────────────────────── */

const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

interface OverpassTags {
  "addr:street"?: string
  "addr:housenumber"?: string
  "addr:city"?: string
  "addr:town"?: string
  "addr:village"?: string
  "addr:suburb"?: string
  "addr:district"?: string
  "addr:county"?: string
  "addr:state"?: string
  "addr:province"?: string
  "addr:region"?: string
  "addr:postcode"?: string
  "addr:country"?: string
}

interface OverpassElement {
  type: string
  id: number
  lat?: number
  lon?: number
  center?: { lat: number; lon: number }
  tags?: OverpassTags
}

interface OverpassResponse {
  elements?: OverpassElement[]
}

interface Anchor {
  latitude: number
  longitude: number
}

/**
 * Collect several real anchor localities (with coordinates) for a
 * country from the country-state-city dataset. Coordinates are ONLY
 * used to aim the Overpass query at populated areas — no name from
 * this dataset is ever returned as address data.
 */
function getAnchors(countryCode: string, limit = 6): Anchor[] {
  const anchors: Anchor[] = []
  const states = State.getStatesOfCountry(countryCode) ?? []

  const shuffledStates = [...states].sort(() => Math.random() - 0.5)
  for (const state of shuffledStates) {
    const cities = City.getCitiesOfState(countryCode, state.isoCode) ?? []
    const withCoords = cities.filter((c) => c.latitude && c.longitude)
    if (withCoords.length > 0) {
      const c = withCoords[Math.floor(Math.random() * withCoords.length)]
      anchors.push({
        latitude: Number.parseFloat(c.latitude as string),
        longitude: Number.parseFloat(c.longitude as string),
      })
    }
    if (anchors.length >= limit) break
  }

  if (anchors.length === 0) {
    // States/cities without coords: try state centroids.
    for (const s of shuffledStates) {
      if (s.latitude && s.longitude) {
        anchors.push({
          latitude: Number.parseFloat(s.latitude as string),
          longitude: Number.parseFloat(s.longitude as string),
        })
      }
      if (anchors.length >= limit) break
    }
  }

  if (anchors.length === 0) {
    // Small territories (Gibraltar, Monaco, etc.): country centroid.
    const country = Country.getCountryByCode(countryCode)
    if (country?.latitude && country?.longitude) {
      anchors.push({
        latitude: Number.parseFloat(country.latitude),
        longitude: Number.parseFloat(country.longitude),
      })
    }
  }

  return anchors
}

/**
 * Query Overpass for address-bearing objects around an anchor point.
 * We search progressively larger radii so sparsely mapped regions
 * still return results.
 */
async function queryOverpass(
  anchor: Anchor,
  radiusMeters: number,
  signal: AbortSignal,
): Promise<OverpassElement[]> {
  // Objects that have BOTH a street name and a house number are the
  // most complete, so request them first via a compact query.
  const query = `
    [out:json][timeout:20];
    (
      node["addr:street"]["addr:housenumber"](around:${radiusMeters},${anchor.latitude},${anchor.longitude});
      way["addr:street"]["addr:housenumber"](around:${radiusMeters},${anchor.latitude},${anchor.longitude});
    );
    out center tags 60;
  `

  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "RandomAddressGenerator/2.0 (educational project)",
        },
        body: `data=${encodeURIComponent(query)}`,
        signal,
      })
      if (!res.ok) continue
      const data = (await res.json()) as OverpassResponse
      if (data.elements && data.elements.length > 0) return data.elements
    } catch {
      // try next endpoint
    }
  }
  return []
}

function extractCity(tags: OverpassTags): string | null {
  return (
    tags["addr:city"] ??
    tags["addr:town"] ??
    tags["addr:village"] ??
    tags["addr:suburb"] ??
    tags["addr:district"] ??
    tags["addr:county"] ??
    null
  )
}

function extractState(tags: OverpassTags): string | null {
  return (
    tags["addr:state"] ??
    tags["addr:province"] ??
    tags["addr:region"] ??
    tags["addr:county"] ??
    null
  )
}

interface NormalizedLocation {
  city: string | null
  state: string | null
  postcode: string | null
}

/** Resolve administrative fields for the exact OSM object coordinate. */
async function normalizeLocation(
  element: OverpassElement,
  countryCode: string,
  signal: AbortSignal,
): Promise<NormalizedLocation | null> {
  const lat = element.lat ?? element.center?.lat
  const lon = element.lon ?? element.center?.lon
  if (lat === undefined || lon === undefined) return null

  const url = new URL("https://nominatim.openstreetmap.org/reverse")
  url.searchParams.set("lat", String(lat))
  url.searchParams.set("lon", String(lon))
  url.searchParams.set("format", "jsonv2")
  url.searchParams.set("addressdetails", "1")
  url.searchParams.set("zoom", "18")
  url.searchParams.set("accept-language", "en")

  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "RandomAddressGenerator/2.0 (educational project)",
      },
      signal,
      next: { revalidate: 86400 },
    })
    if (!response.ok) return null

    const data = (await response.json()) as {
      address?: Record<string, string | undefined>
    }
    const address = data.address
    if (!address || address.country_code?.toUpperCase() !== countryCode) return null

    return {
      city:
        address.city ??
        address.town ??
        address.village ??
        address.hamlet ??
        address.municipality ??
        address.county ??
        null,
      state:
        address.state ??
        address.province ??
        address.region ??
        address.county ??
        null,
      postcode: address.postcode ?? null,
    }
  } catch {
    return null
  }
}

/**
 * Return a genuine address for the country, or null when no
 * address-bearing OSM object can be found (temporary or unsupported).
 *
 * Every returned field is a real OSM tag from a SINGLE object, so the
 * street, house number, city, state, and postcode all belong together.
 */
export async function getRealAddress(
  countryCode: string,
): Promise<RealAddress | null> {
  const anchors = getAnchors(countryCode)
  if (anchors.length === 0) return null

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 25000)

  try {
    // Try each anchor with a growing search radius until we find real
    // address objects.
    for (const anchor of anchors) {
      for (const radius of [1500, 6000, 20000]) {
        const elements = await queryOverpass(anchor, radius, controller.signal)
        if (elements.length === 0) continue

        // Keep only objects with a usable street, then pick one at random.
        const usable = elements.filter((e) => e.tags?.["addr:street"])
        if (usable.length === 0) continue

        const chosen = usable[Math.floor(Math.random() * usable.length)]
        const tags = chosen.tags as OverpassTags

        const streetName = tags["addr:street"]!.trim()
        const houseNumber = tags["addr:housenumber"]?.trim()
        const street = houseNumber ? `${houseNumber} ${streetName}` : streetName

        // Prefer the object's own tags. Missing administrative fields
        // are resolved at this exact object's coordinates, never copied
        // from a random city or fabricated.
        const normalized = await normalizeLocation(
          chosen,
          countryCode,
          controller.signal,
        )
        const city = extractCity(tags) ?? normalized?.city ?? null
        const state = extractState(tags) ?? normalized?.state ?? null

        if (!city || !state) continue

        return {
          street,
          city,
          state,
          zipCode:
            tags["addr:postcode"]?.trim() ?? normalized?.postcode ?? "",
        }
      }
    }
    return null
  } finally {
    clearTimeout(timeout)
  }
}
