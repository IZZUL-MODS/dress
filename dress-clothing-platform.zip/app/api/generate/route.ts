import { NextResponse } from "next/server"
import postalCodes from "postal-codes-js"
import countries from "i18n-iso-countries"
import enLocale from "i18n-iso-countries/langs/en.json"
import { getRealAddress } from "@/lib/get-real-address"
import { supportsAuthenticAddresses } from "@/lib/supported-countries"
import type { ApiError, GeneratedAddress, GenerateRequestBody } from "@/lib/types"

countries.registerLocale(enLocale)

function isGenerateRequestBody(body: unknown): body is GenerateRequestBody {
  return (
    typeof body === "object" &&
    body !== null &&
    "countryCode" in body &&
    typeof (body as Record<string, unknown>).countryCode === "string"
  )
}

export async function POST(request: Request): Promise<NextResponse<GeneratedAddress | ApiError>> {
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 })
  }

  if (!isGenerateRequestBody(body)) {
    return NextResponse.json({ error: "Missing or invalid 'countryCode' field" }, { status: 400 })
  }

  const countryCode = body.countryCode.toUpperCase()
  const countryName = countries.getName(countryCode, "en")

  if (!countryName) {
    return NextResponse.json({ error: `Unknown country code: ${countryCode}` }, { status: 400 })
  }

  if (!supportsAuthenticAddresses(countryCode)) {
    return NextResponse.json(
      { error: "This territory has no authentic civilian street-address coverage." },
      { status: 422 },
    )
  }

  // ── PRIMARY: real address from OpenStreetMap ──────────────────────
  // Street, city, state, and zip all come from the SAME physical
  // point on the map, so they are guaranteed to match 100%.
  const realAddress = await getRealAddress(countryCode)

  if (realAddress) {
    const validationResult = realAddress.zipCode
      ? postalCodes.validate(countryCode, realAddress.zipCode)
      : true // countries without postal codes are considered valid
    const isValid = validationResult === true

    const address: GeneratedAddress = {
      street: realAddress.street,
      city: realAddress.city,
      state: realAddress.state,
      zipCode: realAddress.zipCode || "Tidak berlaku",
      country: countryName,
      countryCode,
      isValid,
      dataSource: "OpenStreetMap",
    }

    return NextResponse.json(address)
  }

  return NextResponse.json(
    {
      error:
        "No verified street address was found. Please try again; synthetic address fallback is disabled.",
    },
    { status: 503 },
  )
}
