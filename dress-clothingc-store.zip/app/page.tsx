import { AddressGenerator } from '@/components/address-generator'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex flex-1 flex-col items-center px-4 pb-4 pt-12 sm:px-6 sm:pt-16">
        <section className="flex w-full max-w-3xl flex-col items-center gap-9 sm:gap-12">
          <div className="flex max-w-2xl flex-col items-center gap-4 text-center">
            <div className="inline-flex items-center rounded-full border border-border bg-background/40 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur-md">
              Instant · Private · Beautiful
            </div>
<div className="relative max-w-3xl space-y-6">
  <div className="absolute -left-10 -top-10 -z-10 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />

  <span className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
    ✦ Smart address generator
  </span>

  <h1 className="text-balance text-4xl font-bold leading-[1.05] tracking-[-0.05em] sm:text-6xl lg:text-7xl">
    Create addresses that feel{" "}
    <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
      real.
    </span>
  </h1>

  <p className="max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
    Generate realistic and coherent addresses in seconds—perfect for
    mockups, testing, prototypes, and wherever your imagination takes you.
  </p>

  <div className="flex flex-wrap gap-3 pt-2">
    <button className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-lg shadow-primary/25 transition hover:-translate-y-0.5 hover:shadow-xl">
      Generate address
    </button>

    <button className="rounded-full border border-border px-5 py-2.5 text-sm font-medium transition hover:bg-muted">
      Explore examples
    </button>
  </div>
</div>
          </div>

          <AddressGenerator />
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
