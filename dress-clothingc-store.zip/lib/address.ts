import type { Country } from './countries'

export type Address = {
  street: string
  city: string
  state: string
  zip: string
  country: string
  countryCode: string
  flag: string
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function pick<T>(list: T[]): T {
  return list[Math.floor(Math.random() * list.length)]
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function zeroPad(n: number, len: number): string {
  return String(n).padStart(len, '0')
}

// ─── Generic street parts (shared across fallback countries) ─────────────────

const STREET_NAMES = [
  'Maple', 'Oakwood', 'Sunset', 'Birchwood', 'Willow Creek', 'Cedar',
  'Highland', 'Riverside', 'Meadowbrook', 'Ashford', 'Kingsley', 'Whitfield',
  'Lakeview', 'Pinehurst', 'Windermere', 'Copperfield', 'Elmhurst', 'Foxglove',
  'Harrowgate', 'Silverstone', 'Greenfield', 'Fernwood', 'Stonegate',
  'Brookside', 'Clearwater', 'Ridgecrest', 'Westgate', 'Northfield',
]

const STREET_SUFFIXES = [
  'Avenue', 'Street', 'Boulevard', 'Lane', 'Drive', 'Court', 'Terrace',
  'Way', 'Place', 'Crescent', 'Road', 'Circle', 'Trail', 'Park',
]

function genericStreet(): string {
  return `${randomInt(1, 9999)} ${pick(STREET_NAMES)} ${pick(STREET_SUFFIXES)}`
}

// ─── Per-country location presets ────────────────────────────────────────────

type LocationEntry = { city: string; state: string }
type CountryPreset = {
  locations: LocationEntry[]
  street: () => string
  zip: () => string
}

const STREET_TYPES_ID = ['Jalan', 'Gang', 'Komplek', 'Perumahan']
const JALAN_NAMES_ID = [
  'Sudirman', 'Thamrin', 'Gatot Subroto', 'Kuningan', 'Rasuna Said',
  'Diponegoro', 'Imam Bonjol', 'Teuku Umar', 'Hayam Wuruk', 'Gajah Mada',
  'Ahmad Yani', 'S. Parman', 'Pelajar Pejuang', 'Mawar', 'Melati',
  'Anggrek', 'Kenanga', 'Bougenvile', 'Cempaka', 'Flamboyan',
]

const PRESETS: Record<string, CountryPreset> = {
  US: {
    locations: [
      { city: 'New York', state: 'New York' },
      { city: 'Los Angeles', state: 'California' },
      { city: 'Chicago', state: 'Illinois' },
      { city: 'Houston', state: 'Texas' },
      { city: 'Phoenix', state: 'Arizona' },
      { city: 'Philadelphia', state: 'Pennsylvania' },
      { city: 'San Antonio', state: 'Texas' },
      { city: 'San Diego', state: 'California' },
      { city: 'Dallas', state: 'Texas' },
      { city: 'San Jose', state: 'California' },
      { city: 'Austin', state: 'Texas' },
      { city: 'Portland', state: 'Oregon' },
      { city: 'Denver', state: 'Colorado' },
      { city: 'Seattle', state: 'Washington' },
      { city: 'Nashville', state: 'Tennessee' },
      { city: 'Boston', state: 'Massachusetts' },
      { city: 'Miami', state: 'Florida' },
      { city: 'Atlanta', state: 'Georgia' },
    ],
    street: () => genericStreet(),
    zip: () => zeroPad(randomInt(10000, 99999), 5),
  },
  CA: {
    locations: [
      { city: 'Toronto', state: 'Ontario' },
      { city: 'Vancouver', state: 'British Columbia' },
      { city: 'Montreal', state: 'Quebec' },
      { city: 'Calgary', state: 'Alberta' },
      { city: 'Edmonton', state: 'Alberta' },
      { city: 'Ottawa', state: 'Ontario' },
      { city: 'Winnipeg', state: 'Manitoba' },
      { city: 'Quebec City', state: 'Quebec' },
      { city: 'Hamilton', state: 'Ontario' },
      { city: 'Halifax', state: 'Nova Scotia' },
    ],
    street: () => `${randomInt(1, 9999)} ${pick(STREET_NAMES)} ${pick(['Street', 'Avenue', 'Drive', 'Boulevard', 'Road', 'Lane', 'Way', 'Court'])}`,
    zip: () => {
      const letters = 'ABCEGHJKLMNPRSTVXY'
      const digits = '0123456789'
      const L = () => letters[randomInt(0, letters.length - 1)]
      const D = () => digits[randomInt(0, 9)]
      return `${L()}${D()}${L()} ${D()}${L()}${D()}`
    },
  },
  GB: {
    locations: [
      { city: 'London', state: 'England' },
      { city: 'Birmingham', state: 'England' },
      { city: 'Manchester', state: 'England' },
      { city: 'Glasgow', state: 'Scotland' },
      { city: 'Liverpool', state: 'England' },
      { city: 'Edinburgh', state: 'Scotland' },
      { city: 'Leeds', state: 'England' },
      { city: 'Bristol', state: 'England' },
      { city: 'Cardiff', state: 'Wales' },
      { city: 'Belfast', state: 'Northern Ireland' },
      { city: 'Sheffield', state: 'England' },
      { city: 'Newcastle', state: 'England' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} ${pick(['Street', 'Road', 'Avenue', 'Lane', 'Close', 'Way', 'Drive', 'Gardens', 'Grove'])}`,
    zip: () => {
      const areas = ['SW1A', 'EC1A', 'W1A', 'SE1', 'WC2N', 'N1', 'E1', 'W2', 'NW1', 'SW3', 'BS1', 'M1', 'B1', 'G1', 'LS1']
      return `${pick(areas)} ${randomInt(1, 9)}${String.fromCharCode(65 + randomInt(0, 25))}${String.fromCharCode(65 + randomInt(0, 25))}`
    },
  },
  AU: {
    locations: [
      { city: 'Sydney', state: 'New South Wales' },
      { city: 'Melbourne', state: 'Victoria' },
      { city: 'Brisbane', state: 'Queensland' },
      { city: 'Perth', state: 'Western Australia' },
      { city: 'Adelaide', state: 'South Australia' },
      { city: 'Canberra', state: 'Australian Capital Territory' },
      { city: 'Hobart', state: 'Tasmania' },
      { city: 'Darwin', state: 'Northern Territory' },
      { city: 'Gold Coast', state: 'Queensland' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} ${pick(['Street', 'Road', 'Avenue', 'Drive', 'Court', 'Place', 'Crescent', 'Way'])}`,
    zip: () => zeroPad(randomInt(2000, 7999), 4),
  },
  ID: {
    locations: [
      { city: 'Jakarta', state: 'DKI Jakarta' },
      { city: 'Surabaya', state: 'Jawa Timur' },
      { city: 'Bandung', state: 'Jawa Barat' },
      { city: 'Medan', state: 'Sumatera Utara' },
      { city: 'Semarang', state: 'Jawa Tengah' },
      { city: 'Makassar', state: 'Sulawesi Selatan' },
      { city: 'Palembang', state: 'Sumatera Selatan' },
      { city: 'Tangerang', state: 'Banten' },
      { city: 'Depok', state: 'Jawa Barat' },
      { city: 'Bekasi', state: 'Jawa Barat' },
      { city: 'Yogyakarta', state: 'DI Yogyakarta' },
      { city: 'Bogor', state: 'Jawa Barat' },
      { city: 'Denpasar', state: 'Bali' },
      { city: 'Balikpapan', state: 'Kalimantan Timur' },
      { city: 'Manado', state: 'Sulawesi Utara' },
    ],
    street: () => `${pick(STREET_TYPES_ID)} ${pick(JALAN_NAMES_ID)} No. ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(10110, 99999), 5),
  },
  JP: {
    locations: [
      { city: 'Tokyo', state: 'Tokyo' },
      { city: 'Osaka', state: 'Osaka' },
      { city: 'Kyoto', state: 'Kyoto' },
      { city: 'Nagoya', state: 'Aichi' },
      { city: 'Sapporo', state: 'Hokkaido' },
      { city: 'Fukuoka', state: 'Fukuoka' },
      { city: 'Kobe', state: 'Hyogo' },
      { city: 'Hiroshima', state: 'Hiroshima' },
      { city: 'Sendai', state: 'Miyagi' },
      { city: 'Yokohama', state: 'Kanagawa' },
    ],
    street: () => `${randomInt(1, 9)}-${randomInt(1, 30)}-${randomInt(1, 50)} ${pick(['Chome', 'Banchi'])}`,
    zip: () => `${zeroPad(randomInt(100, 999), 3)}-${zeroPad(randomInt(0, 9999), 4)}`,
  },
  DE: {
    locations: [
      { city: 'Berlin', state: 'Berlin' },
      { city: 'Munich', state: 'Bavaria' },
      { city: 'Hamburg', state: 'Hamburg' },
      { city: 'Frankfurt', state: 'Hesse' },
      { city: 'Cologne', state: 'North Rhine-Westphalia' },
      { city: 'Stuttgart', state: 'Baden-Württemberg' },
      { city: 'Düsseldorf', state: 'North Rhine-Westphalia' },
      { city: 'Dortmund', state: 'North Rhine-Westphalia' },
      { city: 'Leipzig', state: 'Saxony' },
      { city: 'Bremen', state: 'Bremen' },
    ],
    street: () => `${pick(STREET_NAMES)}straße ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(10115, 99998), 5),
  },
  FR: {
    locations: [
      { city: 'Paris', state: 'Île-de-France' },
      { city: 'Marseille', state: 'Provence-Alpes-Côte d\'Azur' },
      { city: 'Lyon', state: 'Auvergne-Rhône-Alpes' },
      { city: 'Toulouse', state: 'Occitanie' },
      { city: 'Nice', state: 'Provence-Alpes-Côte d\'Azur' },
      { city: 'Nantes', state: 'Pays de la Loire' },
      { city: 'Strasbourg', state: 'Grand Est' },
      { city: 'Montpellier', state: 'Occitanie' },
      { city: 'Bordeaux', state: 'Nouvelle-Aquitaine' },
      { city: 'Lille', state: 'Hauts-de-France' },
    ],
    street: () => `${randomInt(1, 200)} Rue ${pick(STREET_NAMES)}`,
    zip: () => zeroPad(randomInt(1000, 97999), 5),
  },
  IT: {
    locations: [
      { city: 'Rome', state: 'Lazio' },
      { city: 'Milan', state: 'Lombardy' },
      { city: 'Naples', state: 'Campania' },
      { city: 'Turin', state: 'Piedmont' },
      { city: 'Florence', state: 'Tuscany' },
      { city: 'Venice', state: 'Veneto' },
      { city: 'Bologna', state: 'Emilia-Romagna' },
      { city: 'Palermo', state: 'Sicily' },
      { city: 'Genoa', state: 'Liguria' },
    ],
    street: () => `Via ${pick(STREET_NAMES)}, ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(10121, 98168), 5),
  },
  ES: {
    locations: [
      { city: 'Madrid', state: 'Community of Madrid' },
      { city: 'Barcelona', state: 'Catalonia' },
      { city: 'Valencia', state: 'Valencia' },
      { city: 'Seville', state: 'Andalusia' },
      { city: 'Zaragoza', state: 'Aragon' },
      { city: 'Málaga', state: 'Andalusia' },
      { city: 'Bilbao', state: 'Basque Country' },
    ],
    street: () => `Calle ${pick(STREET_NAMES)}, ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1001, 52006), 5),
  },
  BR: {
    locations: [
      { city: 'São Paulo', state: 'São Paulo' },
      { city: 'Rio de Janeiro', state: 'Rio de Janeiro' },
      { city: 'Brasília', state: 'Federal District' },
      { city: 'Salvador', state: 'Bahia' },
      { city: 'Fortaleza', state: 'Ceará' },
      { city: 'Belo Horizonte', state: 'Minas Gerais' },
      { city: 'Curitiba', state: 'Paraná' },
      { city: 'Manaus', state: 'Amazonas' },
      { city: 'Porto Alegre', state: 'Rio Grande do Sul' },
    ],
    street: () => `Rua ${pick(STREET_NAMES)}, ${randomInt(1, 2000)}`,
    zip: () => `${zeroPad(randomInt(1000, 99999), 5)}-${zeroPad(randomInt(0, 999), 3)}`,
  },
  IN: {
    locations: [
      { city: 'Mumbai', state: 'Maharashtra' },
      { city: 'Delhi', state: 'Delhi' },
      { city: 'Bangalore', state: 'Karnataka' },
      { city: 'Hyderabad', state: 'Telangana' },
      { city: 'Chennai', state: 'Tamil Nadu' },
      { city: 'Kolkata', state: 'West Bengal' },
      { city: 'Pune', state: 'Maharashtra' },
      { city: 'Ahmedabad', state: 'Gujarat' },
      { city: 'Jaipur', state: 'Rajasthan' },
      { city: 'Lucknow', state: 'Uttar Pradesh' },
    ],
    street: () => `${randomInt(1, 999)}, ${pick(STREET_NAMES)} ${pick(['Marg', 'Road', 'Street', 'Lane', 'Nagar', 'Colony'])}`,
    zip: () => zeroPad(randomInt(110001, 799999), 6),
  },
  CN: {
    locations: [
      { city: 'Beijing', state: 'Beijing' },
      { city: 'Shanghai', state: 'Shanghai' },
      { city: 'Guangzhou', state: 'Guangdong' },
      { city: 'Shenzhen', state: 'Guangdong' },
      { city: 'Chengdu', state: 'Sichuan' },
      { city: 'Hangzhou', state: 'Zhejiang' },
      { city: 'Wuhan', state: 'Hubei' },
      { city: 'Xi\'an', state: 'Shaanxi' },
      { city: 'Chongqing', state: 'Chongqing' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} Road`,
    zip: () => zeroPad(randomInt(100000, 999999), 6),
  },
  MX: {
    locations: [
      { city: 'Mexico City', state: 'CDMX' },
      { city: 'Guadalajara', state: 'Jalisco' },
      { city: 'Monterrey', state: 'Nuevo León' },
      { city: 'Puebla', state: 'Puebla' },
      { city: 'Tijuana', state: 'Baja California' },
      { city: 'León', state: 'Guanajuato' },
      { city: 'Cancún', state: 'Quintana Roo' },
    ],
    street: () => `Calle ${pick(STREET_NAMES)} #${randomInt(1, 999)}`,
    zip: () => zeroPad(randomInt(1000, 99999), 5),
  },
  RU: {
    locations: [
      { city: 'Moscow', state: 'Moscow' },
      { city: 'Saint Petersburg', state: 'Saint Petersburg' },
      { city: 'Novosibirsk', state: 'Novosibirsk Oblast' },
      { city: 'Yekaterinburg', state: 'Sverdlovsk Oblast' },
      { city: 'Kazan', state: 'Tatarstan' },
    ],
    street: () => `ul. ${pick(STREET_NAMES)}, d. ${randomInt(1, 200)}, kv. ${randomInt(1, 500)}`,
    zip: () => zeroPad(randomInt(100000, 999999), 6),
  },
  ZA: {
    locations: [
      { city: 'Johannesburg', state: 'Gauteng' },
      { city: 'Cape Town', state: 'Western Cape' },
      { city: 'Durban', state: 'KwaZulu-Natal' },
      { city: 'Pretoria', state: 'Gauteng' },
      { city: 'Port Elizabeth', state: 'Eastern Cape' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} ${pick(['Street', 'Road', 'Avenue', 'Drive', 'Lane'])}`,
    zip: () => zeroPad(randomInt(1000, 9999), 4),
  },
  NG: {
    locations: [
      { city: 'Lagos', state: 'Lagos' },
      { city: 'Abuja', state: 'FCT' },
      { city: 'Kano', state: 'Kano' },
      { city: 'Ibadan', state: 'Oyo' },
      { city: 'Port Harcourt', state: 'Rivers' },
    ],
    street: () => `${randomInt(1, 200)} ${pick(STREET_NAMES)} ${pick(['Street', 'Close', 'Drive', 'Avenue', 'Crescent'])}`,
    zip: () => zeroPad(randomInt(100001, 999999), 6),
  },
  KR: {
    locations: [
      { city: 'Seoul', state: 'Seoul' },
      { city: 'Busan', state: 'Busan' },
      { city: 'Incheon', state: 'Incheon' },
      { city: 'Daegu', state: 'Daegu' },
      { city: 'Daejeon', state: 'Daejeon' },
      { city: 'Gwangju', state: 'Gwangju' },
    ],
    street: () => `${randomInt(1, 999)}-${randomInt(1, 99)} ${pick(STREET_NAMES)}-ro`,
    zip: () => zeroPad(randomInt(1000, 99999), 5),
  },
  SA: {
    locations: [
      { city: 'Riyadh', state: 'Riyadh' },
      { city: 'Jeddah', state: 'Mecca' },
      { city: 'Mecca', state: 'Mecca' },
      { city: 'Medina', state: 'Medina' },
      { city: 'Dammam', state: 'Eastern Province' },
    ],
    street: () => `${randomInt(1, 9999)} ${pick(STREET_NAMES)} Street`,
    zip: () => zeroPad(randomInt(11311, 99999), 5),
  },
  AE: {
    locations: [
      { city: 'Dubai', state: 'Dubai' },
      { city: 'Abu Dhabi', state: 'Abu Dhabi' },
      { city: 'Sharjah', state: 'Sharjah' },
      { city: 'Ajman', state: 'Ajman' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} Road`,
    zip: () => zeroPad(randomInt(10000, 99999), 5),
  },
  SG: {
    locations: [
      { city: 'Singapore', state: 'Singapore' },
    ],
    street: () => `Block ${randomInt(1, 999)}, ${randomInt(1, 20)}${String.fromCharCode(65 + randomInt(0, 5))} ${pick(STREET_NAMES)} Road`,
    zip: () => zeroPad(randomInt(18906, 829978), 6),
  },
  MY: {
    locations: [
      { city: 'Kuala Lumpur', state: 'Kuala Lumpur' },
      { city: 'George Town', state: 'Penang' },
      { city: 'Ipoh', state: 'Perak' },
      { city: 'Shah Alam', state: 'Selangor' },
      { city: 'Johor Bahru', state: 'Johor' },
      { city: 'Kota Kinabalu', state: 'Sabah' },
      { city: 'Kuching', state: 'Sarawak' },
    ],
    street: () => `${randomInt(1, 999)}, Jalan ${pick(STREET_NAMES)}`,
    zip: () => zeroPad(randomInt(10000, 98999), 5),
  },
  NL: {
    locations: [
      { city: 'Amsterdam', state: 'North Holland' },
      { city: 'Rotterdam', state: 'South Holland' },
      { city: 'The Hague', state: 'South Holland' },
      { city: 'Utrecht', state: 'Utrecht' },
      { city: 'Eindhoven', state: 'North Brabant' },
    ],
    street: () => `${pick(STREET_NAMES)}straat ${randomInt(1, 999)}`,
    zip: () => `${zeroPad(randomInt(1000, 9999), 4)} ${String.fromCharCode(65 + randomInt(0, 25))}${String.fromCharCode(65 + randomInt(0, 25))}`,
  },
  NZ: {
    locations: [
      { city: 'Auckland', state: 'Auckland' },
      { city: 'Wellington', state: 'Wellington' },
      { city: 'Christchurch', state: 'Canterbury' },
      { city: 'Hamilton', state: 'Waikato' },
      { city: 'Dunedin', state: 'Otago' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} ${pick(['Street', 'Road', 'Avenue', 'Drive', 'Place', 'Crescent', 'Lane'])}`,
    zip: () => zeroPad(randomInt(1001, 9999), 4),
  },
  PH: {
    locations: [
      { city: 'Manila', state: 'Metro Manila' },
      { city: 'Quezon City', state: 'Metro Manila' },
      { city: 'Cebu City', state: 'Cebu' },
      { city: 'Davao City', state: 'Davao del Sur' },
      { city: 'Makati', state: 'Metro Manila' },
    ],
    street: () => `${randomInt(1, 9999)} ${pick(STREET_NAMES)} St.`,
    zip: () => zeroPad(randomInt(1000, 9999), 4),
  },
  TH: {
    locations: [
      { city: 'Bangkok', state: 'Bangkok' },
      { city: 'Chiang Mai', state: 'Chiang Mai' },
      { city: 'Pattaya', state: 'Chonburi' },
      { city: 'Phuket', state: 'Phuket' },
    ],
    street: () => `${randomInt(1, 999)} ${pick(STREET_NAMES)} Road`,
    zip: () => zeroPad(randomInt(10100, 96220), 5),
  },
  PK: {
    locations: [
      { city: 'Karachi', state: 'Sindh' },
      { city: 'Lahore', state: 'Punjab' },
      { city: 'Islamabad', state: 'Islamabad Capital Territory' },
      { city: 'Rawalpindi', state: 'Punjab' },
      { city: 'Faisalabad', state: 'Punjab' },
    ],
    street: () => `House ${randomInt(1, 999)}, Street ${randomInt(1, 50)}, ${pick(STREET_NAMES)} Area`,
    zip: () => zeroPad(randomInt(10000, 99999), 5),
  },
  BD: {
    locations: [
      { city: 'Dhaka', state: 'Dhaka Division' },
      { city: 'Chittagong', state: 'Chittagong Division' },
      { city: 'Sylhet', state: 'Sylhet Division' },
      { city: 'Rajshahi', state: 'Rajshahi Division' },
    ],
    street: () => `${randomInt(1, 999)}, ${pick(STREET_NAMES)} Road`,
    zip: () => zeroPad(randomInt(1000, 9999), 4),
  },
  EG: {
    locations: [
      { city: 'Cairo', state: 'Cairo' },
      { city: 'Alexandria', state: 'Alexandria' },
      { city: 'Giza', state: 'Giza' },
      { city: 'Luxor', state: 'Luxor' },
    ],
    street: () => `${randomInt(1, 200)} ${pick(STREET_NAMES)} Street`,
    zip: () => zeroPad(randomInt(11511, 99999), 5),
  },
  AR: {
    locations: [
      { city: 'Buenos Aires', state: 'Buenos Aires' },
      { city: 'Córdoba', state: 'Córdoba' },
      { city: 'Rosario', state: 'Santa Fe' },
      { city: 'Mendoza', state: 'Mendoza' },
    ],
    street: () => `${pick(STREET_NAMES)} ${randomInt(100, 9999)}`,
    zip: () => `${String.fromCharCode(65 + randomInt(0, 25))}${zeroPad(randomInt(1000, 9999), 4)}${String.fromCharCode(65 + randomInt(0, 25))}${String.fromCharCode(65 + randomInt(0, 25))}${String.fromCharCode(65 + randomInt(0, 25))}`,
  },
  TR: {
    locations: [
      { city: 'Istanbul', state: 'Istanbul' },
      { city: 'Ankara', state: 'Ankara' },
      { city: 'Izmir', state: 'Izmir' },
      { city: 'Bursa', state: 'Bursa' },
      { city: 'Antalya', state: 'Antalya' },
    ],
    street: () => `${pick(STREET_NAMES)} Caddesi No: ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1000, 81999), 5),
  },
  PL: {
    locations: [
      { city: 'Warsaw', state: 'Masovian' },
      { city: 'Kraków', state: 'Lesser Poland' },
      { city: 'Gdańsk', state: 'Pomeranian' },
      { city: 'Wrocław', state: 'Lower Silesian' },
      { city: 'Poznań', state: 'Greater Poland' },
    ],
    street: () => `ul. ${pick(STREET_NAMES)} ${randomInt(1, 200)}`,
    zip: () => `${zeroPad(randomInt(0, 99), 2)}-${zeroPad(randomInt(0, 999), 3)}`,
  },
  PT: {
    locations: [
      { city: 'Lisbon', state: 'Lisbon' },
      { city: 'Porto', state: 'Porto' },
      { city: 'Braga', state: 'Braga' },
      { city: 'Coimbra', state: 'Coimbra' },
    ],
    street: () => `Rua ${pick(STREET_NAMES)}, ${randomInt(1, 500)}`,
    zip: () => `${zeroPad(randomInt(1000, 9999), 4)}-${zeroPad(randomInt(0, 999), 3)}`,
  },
  SE: {
    locations: [
      { city: 'Stockholm', state: 'Stockholm County' },
      { city: 'Gothenburg', state: 'Västra Götaland County' },
      { city: 'Malmö', state: 'Skåne County' },
      { city: 'Uppsala', state: 'Uppsala County' },
    ],
    street: () => `${pick(STREET_NAMES)}gatan ${randomInt(1, 200)}`,
    zip: () => `${zeroPad(randomInt(10000, 99999), 5)}`,
  },
  NO: {
    locations: [
      { city: 'Oslo', state: 'Oslo' },
      { city: 'Bergen', state: 'Vestland' },
      { city: 'Trondheim', state: 'Trøndelag' },
    ],
    street: () => `${pick(STREET_NAMES)}veien ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1000, 9999), 4),
  },
  DK: {
    locations: [
      { city: 'Copenhagen', state: 'Capital Region' },
      { city: 'Aarhus', state: 'Central Jutland' },
      { city: 'Odense', state: 'Southern Denmark' },
    ],
    street: () => `${pick(STREET_NAMES)}gade ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1000, 9990), 4),
  },
  FI: {
    locations: [
      { city: 'Helsinki', state: 'Uusimaa' },
      { city: 'Tampere', state: 'Pirkanmaa' },
      { city: 'Turku', state: 'Finland Proper' },
    ],
    street: () => `${pick(STREET_NAMES)}tie ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(10000, 99800), 5),
  },
  BE: {
    locations: [
      { city: 'Brussels', state: 'Brussels-Capital' },
      { city: 'Antwerp', state: 'Antwerp' },
      { city: 'Ghent', state: 'East Flanders' },
      { city: 'Liège', state: 'Liège' },
    ],
    street: () => `Rue ${pick(STREET_NAMES)} ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1000, 9999), 4),
  },
  CH: {
    locations: [
      { city: 'Zurich', state: 'Zurich' },
      { city: 'Geneva', state: 'Geneva' },
      { city: 'Basel', state: 'Basel-City' },
      { city: 'Bern', state: 'Bern' },
      { city: 'Lausanne', state: 'Vaud' },
    ],
    street: () => `${pick(STREET_NAMES)}strasse ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1000, 9658), 4),
  },
  AT: {
    locations: [
      { city: 'Vienna', state: 'Vienna' },
      { city: 'Graz', state: 'Styria' },
      { city: 'Linz', state: 'Upper Austria' },
      { city: 'Salzburg', state: 'Salzburg' },
      { city: 'Innsbruck', state: 'Tyrol' },
    ],
    street: () => `${pick(STREET_NAMES)}gasse ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1010, 9992), 4),
  },
  HU: {
    locations: [
      { city: 'Budapest', state: 'Budapest' },
      { city: 'Debrecen', state: 'Hajdú-Bihar' },
      { city: 'Miskolc', state: 'Borsod-Abaúj-Zemplén' },
    ],
    street: () => `${pick(STREET_NAMES)} utca ${randomInt(1, 200)}.`,
    zip: () => zeroPad(randomInt(1011, 9985), 4),
  },
  RO: {
    locations: [
      { city: 'Bucharest', state: 'Ilfov' },
      { city: 'Cluj-Napoca', state: 'Cluj' },
      { city: 'Timișoara', state: 'Timiș' },
    ],
    street: () => `Strada ${pick(STREET_NAMES)} nr. ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(10001, 925400), 6),
  },
  UA: {
    locations: [
      { city: 'Kyiv', state: 'Kyiv Oblast' },
      { city: 'Kharkiv', state: 'Kharkiv Oblast' },
      { city: 'Odessa', state: 'Odessa Oblast' },
      { city: 'Lviv', state: 'Lviv Oblast' },
    ],
    street: () => `vul. ${pick(STREET_NAMES)}, ${randomInt(1, 200)}`,
    zip: () => zeroPad(randomInt(1001, 99999), 5),
  },
  IL: {
    locations: [
      { city: 'Tel Aviv', state: 'Tel Aviv' },
      { city: 'Jerusalem', state: 'Jerusalem' },
      { city: 'Haifa', state: 'Haifa' },
    ],
    street: () => `${randomInt(1, 200)} ${pick(STREET_NAMES)} Street`,
    zip: () => zeroPad(randomInt(1000000, 9999999), 7),
  },
  GR: {
    locations: [
      { city: 'Athens', state: 'Attica' },
      { city: 'Thessaloniki', state: 'Central Macedonia' },
      { city: 'Heraklion', state: 'Crete' },
    ],
    street: () => `${pick(STREET_NAMES)} ${randomInt(1, 200)}`,
    zip: () => `${zeroPad(randomInt(10000, 85700), 5)}`,
  },
  CZ: {
    locations: [
      { city: 'Prague', state: 'Prague' },
      { city: 'Brno', state: 'South Moravian' },
      { city: 'Ostrava', state: 'Moravian-Silesian' },
    ],
    street: () => `${pick(STREET_NAMES)}ova ${randomInt(1, 200)}`,
    zip: () => `${zeroPad(randomInt(100, 999), 3)} ${zeroPad(randomInt(0, 99), 2)}`,
  },
}

// ─── Fallback generator for any country not in PRESETS ───────────────────────

function fallbackPreset(countryName: string): CountryPreset {
  return {
    locations: [{ city: countryName + ' City', state: 'Central District' }],
    street: genericStreet,
    zip: () => zeroPad(randomInt(10000, 99999), 5),
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

export function generateAddress(
  country: Country,
  previous?: Address,
): Address {
  const preset = PRESETS[country.code] ?? fallbackPreset(country.name)

  let next: Address
  do {
    const location = pick(preset.locations)
    next = {
      street: preset.street(),
      city: location.city,
      state: location.state,
      zip: preset.zip(),
      country: country.name,
      countryCode: country.code,
      flag: country.flag,
    }
  } while (previous && next.street === previous.street)

  return next
}

export function formatAddress(address: Address): string {
  return `${address.street}\n${address.city}, ${address.state} ${address.zip}\n${address.country}`
}
