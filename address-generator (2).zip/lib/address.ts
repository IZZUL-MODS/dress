import type { Country } from './countries'

export type Address = {
  street: string
  city: string
  state: string
  zip: string
  country: string
  countryCode: string
  flag: string
}

export async function fetchVerifiedAddress(
  country: Country,
  previous?: Address,
): Promise<Address> {
  const params = new URLSearchParams({
    country: country.code,
    previous: previous ? formatAddress(previous) : '',
  })
  const response = await fetch(`/api/address?${params.toString()}`, {
    cache: 'no-store',
  })
  const payload = (await response.json()) as Address | { error?: string }

  if (!response.ok || 'error' in payload) {
    throw new Error('error' in payload ? payload.error : 'Address lookup failed')
  }

  if (!('street' in payload)) {
    throw new Error('The address service returned an invalid response.')
  }

  return payload
}

export function formatAddress(address: Address): string {
  return `${address.street}\n${address.city}, ${address.state} ${address.zip}\n${address.country}`
}
