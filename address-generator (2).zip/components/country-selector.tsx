'use client'

import * as React from 'react'
import { ChevronDown, Globe, Search, X } from 'lucide-react'

import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { CountryFlag } from '@/components/country-flag'
import { cn } from '@/lib/utils'
import { COUNTRIES, type Country } from '@/lib/countries'

// ─── Virtualized scroll list ─────────────────────────────────────────────────
// We render all items inside CommandList which handles its own overflow scroll.
// For a 249-entry list performance is fine without a virtual scroller.

// ─── Highlighted match helper ────────────────────────────────────────────────
function HighlightMatch({
  text,
  query,
}: {
  text: string
  query: string
}) {
  if (!query.trim()) return <span>{text}</span>
  const idx = text.toLowerCase().indexOf(query.toLowerCase())
  if (idx === -1) return <span>{text}</span>
  return (
    <span>
      {text.slice(0, idx)}
      <span className="text-primary font-semibold">{text.slice(idx, idx + query.length)}</span>
      {text.slice(idx + query.length)}
    </span>
  )
}

// ─── Component ───────────────────────────────────────────────────────────────
interface CountrySelectorProps {
  value: Country | null
  onChange: (country: Country) => void
  disabled?: boolean
}

export function CountrySelector({
  value,
  onChange,
  disabled = false,
}: CountrySelectorProps) {
  const [open, setOpen] = React.useState(false)
  const [query, setQuery] = React.useState('')

  // Filter countries based on query
  const filtered = React.useMemo(() => {
    if (!query.trim()) return COUNTRIES
    const lower = query.toLowerCase()
    return COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(lower) ||
        c.code.toLowerCase().includes(lower),
    )
  }, [query])

  function handleSelect(country: Country) {
    onChange(country)
    setOpen(false)
    setQuery('')
  }

  function handleOpenChange(next: boolean) {
    setOpen(next)
    if (!next) setQuery('')
  }

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      {/* Trigger */}
      <PopoverTrigger
        disabled={disabled}
        className={cn(
          'group relative flex w-full items-center gap-3 rounded-xl',
          'h-12 px-4 text-sm font-medium',
          'glass-surface',
          'transition-all duration-200 ease-spring',
          'hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60',
          'disabled:cursor-not-allowed disabled:opacity-50',
          open && 'ring-2 ring-ring/60',
        )}
        aria-label="Select country"
      >
        {/* Flag / globe */}
        <span className="flex size-7 shrink-0 items-center justify-center rounded-lg bg-muted p-1">
          {value ? (
            <CountryFlag code={value.code} name={value.name} className="w-full" />
          ) : (
            <Globe className="size-4 text-muted-foreground" />
          )}
        </span>

        {/* Label */}
        <span
          className={cn(
            'flex-1 truncate text-left',
            !value && 'text-muted-foreground',
          )}
        >
          {value ? value.name : 'Select country…'}
        </span>

        {/* Trailing chevron */}
        <ChevronDown
          className={cn(
            'size-4 shrink-0 text-muted-foreground transition-transform duration-300 ease-spring',
            open && 'rotate-180',
          )}
        />
      </PopoverTrigger>

      {/* Dropdown panel */}
      <PopoverContent
        className={cn(
          'p-0 w-[var(--radix-popover-trigger-width,320px)]',
          'overflow-hidden rounded-2xl',
          // Override default popover width to match trigger
          'min-w-[320px]',
          // premium glass
          'glass-surface border border-white/10',
          'shadow-[0_24px_60px_oklch(0_0_0_/_0.35),0_4px_12px_oklch(0_0_0_/_0.2)]',
          // smooth spring open animation
          'data-[state=open]:animate-in data-[state=closed]:animate-out',
          'data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0',
          'data-[state=open]:zoom-in-95 data-[state=closed]:zoom-out-95',
          'data-[state=open]:slide-in-from-top-2 data-[state=closed]:slide-out-to-top-2',
          '[animation-duration:220ms] [animation-timing-function:cubic-bezier(0.16,1,0.3,1)]',
        )}
        side="bottom"
        sideOffset={6}
      >
        {/* Search input — custom, not CommandInput which has a fixed inner wrapper */}
        <div className="flex items-center gap-2 border-b border-border/40 px-3 py-2.5">
          <Search className="size-4 shrink-0 text-muted-foreground" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search country or code…"
            className={cn(
              'flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground',
              'outline-none',
            )}
            aria-label="Search countries"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="rounded-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              aria-label="Clear search"
            >
              <X className="size-3.5" />
            </button>
          )}
        </div>

        {/* Country list */}
        <Command
          // Disable cmdk filtering since we do our own
          filter={() => 1}
          className="bg-transparent! rounded-none! p-0!"
        >
          <CommandList className="max-h-[280px] overflow-y-auto scroll-py-1">
            {filtered.length === 0 ? (
              <CommandEmpty className="py-8 text-muted-foreground">
                No country found for &ldquo;{query}&rdquo;
              </CommandEmpty>
            ) : (
              <CommandGroup className="p-1">
                {filtered.map((country) => {
                  const isSelected = value?.code === country.code
                  return (
                    <CommandItem
                      key={country.code}
                      value={country.code}
                      data-checked={isSelected}
                      onSelect={() => handleSelect(country)}
                      className={cn(
                        'group flex cursor-pointer items-center gap-3 rounded-lg px-2.5 py-2',
                        'transition-colors duration-100',
                        'aria-selected:bg-muted',
                        isSelected && 'bg-primary/10 text-primary',
                      )}
                    >
                      {/* Flag */}
                      <span className="flex size-7 shrink-0 items-center justify-center rounded-md bg-muted p-1">
                        <CountryFlag
                          code={country.code}
                          name={country.name}
                          className="w-full"
                        />
                      </span>

                      {/* Name + code */}
                      <span className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate text-sm font-medium leading-snug">
                          <HighlightMatch text={country.name} query={query} />
                        </span>
                        <span className="text-[0.65rem] font-mono text-muted-foreground leading-none mt-0.5">
                          {country.code}
                        </span>
                      </span>

                      {/* Selected check */}
                      {isSelected && (
                        <span className="ml-auto size-1.5 rounded-full bg-primary" aria-hidden="true" />
                      )}
                    </CommandItem>
                  )
                })}
              </CommandGroup>
            )}
          </CommandList>
        </Command>

        {/* Footer count */}
        <div className="border-t border-border/30 px-3 py-1.5">
          <p className="text-[0.65rem] text-muted-foreground">
            {filtered.length} of {COUNTRIES.length} countries
          </p>
        </div>
      </PopoverContent>
    </Popover>
  )
}
