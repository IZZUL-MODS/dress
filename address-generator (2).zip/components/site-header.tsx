import { ThemeToggle } from '@/components/theme-toggle'

export function SiteHeader() {
  return (
    <header className="sticky top-4 z-50 mx-auto w-full max-w-3xl px-4 sm:top-6">
      <div className="glass-surface flex items-center justify-between rounded-full px-4 py-2.5 sm:px-6 sm:py-3">
        <a
          href="/"
          className="text-gradient-logo text-xl font-extrabold tracking-tight sm:text-2xl"
        >
          Zulzz
        </a>
        <ThemeToggle />
      </div>
    </header>
  )
}
