import { Globe2 } from 'lucide-react'

import { cn } from '@/lib/utils'

interface CountryFlagProps {
  code: string
  name: string
  className?: string
  decorative?: boolean
}

export function CountryFlag({
  code,
  name,
  className,
  decorative = false,
}: CountryFlagProps) {
  const normalizedCode = code.trim().toLowerCase()
  const isValidCode = /^[a-z]{2}$/.test(normalizedCode)

  if (!isValidCode) {
    return (
      <Globe2
        className={cn('size-4 text-muted-foreground', className)}
        aria-hidden={decorative || undefined}
        aria-label={decorative ? undefined : name}
      />
    )
  }

  return (
    <span
      className={cn(
        'fi block aspect-[4/3] shrink-0 overflow-hidden rounded-[0.2rem] bg-cover bg-center shadow-sm ring-1 ring-foreground/10',
        `fi-${normalizedCode}`,
        className,
      )}
      role={decorative ? undefined : 'img'}
      aria-hidden={decorative || undefined}
      aria-label={decorative ? undefined : `${name} flag`}
    />
  )
}
