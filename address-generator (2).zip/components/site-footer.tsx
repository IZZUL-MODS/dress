export function SiteFooter() {
  return (
    <footer className="mt-auto w-full py-8 text-center">
      <p className="text-xs text-muted-foreground sm:text-sm">
        {'\u00A9'} 2024{' '}
        <span className="link-underline cursor-default font-medium text-foreground/70 transition-colors hover:text-foreground">
          Zulzz
        </span>
        . All rights reserved.
      </p>
    </footer>
  )
}
