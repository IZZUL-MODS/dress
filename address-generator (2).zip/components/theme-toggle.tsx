'use client'

import { useCallback, useEffect, useState } from 'react'
import { Moon, Sun } from 'lucide-react'

import { cn } from '@/lib/utils'

type Theme = 'light' | 'dark'

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>('dark')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const current = document.documentElement.classList.contains('dark')
      ? 'dark'
      : 'light'
    setTheme(current)
    setMounted(true)
  }, [])

  const toggle = useCallback(() => {
    setTheme((prev) => {
      const next: Theme = prev === 'dark' ? 'light' : 'dark'
      const root = document.documentElement
      root.classList.remove('light', 'dark')
      root.classList.add(next)
      try {
        localStorage.setItem('zulzz-theme', next)
      } catch {
        // Ignore storage failures (e.g. private mode).
      }
      return next
    })
  }, [])

  const isDark = theme === 'dark'

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      className={cn(
        'group relative grid size-10 place-items-center overflow-hidden rounded-full',
        'border border-border bg-background/40 backdrop-blur-md',
        'transition-all duration-300 ease-spring hover:bg-background/70',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
      )}
    >
      <Sun
        className={cn(
          'absolute size-[18px] text-foreground transition-all duration-500 ease-spring',
          mounted && isDark
            ? 'rotate-180 scale-50 opacity-0'
            : 'rotate-0 scale-100 opacity-100',
        )}
      />
      <Moon
        className={cn(
          'absolute size-[18px] text-foreground transition-all duration-500 ease-spring',
          mounted && isDark
            ? 'rotate-0 scale-100 opacity-100'
            : '-rotate-180 scale-50 opacity-0',
        )}
      />
    </button>
  )
}
