'use client'

import { useCallback, useRef, useState } from 'react'
import { Check, Copy, Globe2, MapPin, RefreshCw, Sparkles } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'
import { fetchVerifiedAddress, formatAddress, type Address } from '@/lib/address'
import { COUNTRIES, type Country } from '@/lib/countries'
import { CountrySelector } from '@/components/country-selector'
import { CountryFlag } from '@/components/country-flag'

// Default to Indonesia
const DEFAULT_COUNTRY: Country = COUNTRIES.find((c) => c.code === 'ID')!

// ─── Sub-components ────────────────────────────────────────────────────────

function DetailField({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[0.68rem] font-medium uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <span className="text-sm font-medium text-foreground/90 sm:text-[0.95rem] leading-snug">
        {value}
      </span>
    </div>
  )
}

function AddressSkeleton() {
  return (
    <div className="flex flex-col gap-6" aria-hidden="true">
      <div className="flex flex-col gap-3">
        <Skeleton className="skeleton-wave h-4 w-24 rounded-md" />
        <Skeleton className="skeleton-wave h-8 w-3/4 rounded-lg sm:h-10" />
      </div>
      <div className="grid grid-cols-2 gap-5">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex flex-col gap-2">
            <Skeleton className="skeleton-wave h-3 w-16 rounded" />
            <Skeleton className="skeleton-wave h-5 w-24 rounded" />
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Main component ────────────────────────────────────────────────────────

export function AddressGenerator() {
  const [selectedCountry, setSelectedCountry] = useState<Country>(DEFAULT_COUNTRY)
  const [address, setAddress] = useState<Address | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [revealKey, setRevealKey] = useState(0)
  const copyTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const handleCountryChange = useCallback((country: Country) => {
    setSelectedCountry(country)
    setAddress(null)
    setError(null)
    setCopied(false)
  }, [])

  const handleGenerate = useCallback(async () => {
    setLoading(true)
    setError(null)
    setCopied(false)

    try {
      const [nextAddress] = await Promise.all([
        fetchVerifiedAddress(selectedCountry, address ?? undefined),
        new Promise((resolve) => window.setTimeout(resolve, 500)),
      ])
      setAddress(nextAddress)
      setRevealKey((key) => key + 1)
    } catch (reason) {
      setAddress(null)
      setError(reason instanceof Error ? reason.message : 'Unable to verify an address right now.')
    } finally {
      setLoading(false)
    }
  }, [selectedCountry, address])

  const handleCopy = useCallback(async () => {
    if (!address) return
    try {
      await navigator.clipboard.writeText(formatAddress(address))
      setCopied(true)
      if (copyTimer.current) clearTimeout(copyTimer.current)
      copyTimer.current = setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }, [address])

  const hasAddress = address !== null

  return (
    <div className="grid w-full max-w-3xl grid-cols-1 gap-4 sm:grid-cols-6">

      {/* ── Hero address card ──────────────────────────────────────────── */}
      <Card className="glass-surface col-span-1 rounded-3xl border-0 p-6 sm:col-span-6 sm:p-8">
        <CardContent className="px-0">
          <div className="mb-6 flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-full bg-primary/10 text-primary">
              <MapPin className="size-4" />
            </span>
            <span className="text-sm font-medium text-muted-foreground">
              Generated Address
            </span>
            {hasAddress && (
              <span
                className="ml-auto flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground"
                title={address.country}
              >
                <CountryFlag
                  code={address.countryCode}
                  name={address.country}
                  className="w-5"
                />
                <span className="font-mono text-[0.68rem]">{address.countryCode}</span>
              </span>
            )}
          </div>

          <div
            aria-live="polite"
            aria-busy={loading}
            className="min-h-[172px]"
          >
            {loading ? (
              <AddressSkeleton />
            ) : hasAddress ? (
              <div key={revealKey} className="animate-reveal flex flex-col gap-6">
                <div className="flex flex-col gap-1.5">
                  <span className="text-[0.68rem] font-medium uppercase tracking-widest text-muted-foreground">
                    Street Address
                  </span>
                  <h2 className="text-2xl font-semibold leading-tight tracking-tight text-balance sm:text-4xl">
                    {address.street}
                  </h2>
                </div>
                <div className="grid grid-cols-2 gap-5 sm:grid-cols-4">
                  <DetailField label="City" value={address.city} />
                  <DetailField label="State / Region" value={address.state} />
                  <DetailField label="Zip / Postal" value={address.zip} />
                  <DetailField label="Country" value={address.country} />
                </div>
              </div>
            ) : (
              <div className="flex h-[172px] flex-col items-center justify-center gap-3 text-center">
                <span className="grid size-12 place-items-center rounded-2xl bg-muted text-muted-foreground">
                  <Sparkles className="size-5" />
                </span>
                <p className="max-w-sm text-pretty text-sm text-muted-foreground">
                  {error ? (
                    <span role="alert">{error}</span>
                  ) : (
                    <>
                      Choose a country below, then tap{' '}
                      <span className="font-medium text-foreground">Generate</span> to find
                      a real address recorded in OpenStreetMap.
                    </>
                  )}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Country selector card ──────────────────────────────────────── */}
      <Card className="glass-surface col-span-1 rounded-3xl border-0 p-5 sm:col-span-6">
        <CardContent className="px-0">
          <div className="flex items-center gap-2 mb-3">
            <Globe2 className="size-3.5 text-muted-foreground" />
            <span className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
              Country
            </span>
          </div>
          <CountrySelector
            value={selectedCountry}
            onChange={handleCountryChange}
            disabled={loading}
          />
        </CardContent>
      </Card>

      {/* ── Generate action ────────────────────────────────────────────── */}
      <Card className="glass-surface col-span-1 flex flex-col justify-center rounded-3xl border-0 p-5 sm:col-span-4">
        <CardContent className="flex flex-col gap-2 px-0">
          <p className="text-sm text-muted-foreground">
            Fresh, coherent addresses on demand.
          </p>
          <TactileButton onClick={handleGenerate} disabled={loading}>
            <RefreshCw
              data-icon="inline-start"
              className={cn('size-4', loading && 'animate-spin')}
            />
            {loading ? 'Generating…' : 'Generate Address'}
          </TactileButton>
        </CardContent>
      </Card>

      {/* ── Copy action ────────────────────────────────────────────────── */}
      <Card className="glass-surface col-span-1 flex flex-col justify-center rounded-3xl border-0 p-5 sm:col-span-2">
        <CardContent className="flex flex-col gap-2 px-0">
          <p className="text-sm text-muted-foreground">Copy to clipboard</p>
          <TactileButton
            variant="secondary"
            onClick={handleCopy}
            disabled={!hasAddress || loading}
          >
            {copied ? (
              <>
                <Check data-icon="inline-start" className="size-4" />
                Copied!
              </>
            ) : (
              <>
                <Copy data-icon="inline-start" className="size-4" />
                Copy
              </>
            )}
          </TactileButton>
        </CardContent>
      </Card>
    </div>
  )
}

// ─── TactileButton ─────────────────────────────────────────────────────────

function TactileButton({
  children,
  variant = 'default',
  className,
  ...props
}: React.ComponentProps<typeof Button>) {
  return (
    <div className="group/tactile relative">
      <span
        aria-hidden="true"
        className={cn(
          'pointer-events-none absolute inset-x-2 bottom-0 h-full rounded-xl opacity-0 blur-lg transition-opacity duration-300 group-hover/tactile:opacity-70',
          variant === 'default' ? 'bg-primary/50' : 'bg-foreground/15',
        )}
      />
      <Button
        variant={variant}
        size="lg"
        className={cn(
          'relative h-11 w-full rounded-xl text-sm font-semibold',
          'transition-all duration-300 ease-spring',
          'hover:-translate-y-0.5 hover:scale-[1.02] active:scale-95',
          className,
        )}
        {...props}
      >
        {children}
      </Button>
    </div>
  )
}
