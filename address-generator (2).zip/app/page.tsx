'use client'

import Link from 'next/link'
import { AddressGenerator } from '@/components/address-generator'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex flex-1 flex-col items-center px-4 pb-4 pt-12 sm:px-6 sm:pt-16">
        <section className="flex w-full max-w-3xl flex-col items-center gap-9 sm:gap-12" id="address-generator-section">
          <div className="flex max-w-2xl flex-col items-center gap-4 text-center">
<div className="relative max-w-3xl space-y-6">
  <div className="absolute -left-10 -top-10 -z-10 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />

  <span className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
    ✦ Smart address generator
  </span>

  <h1 className="text-balance text-4xl font-bold leading-[1.05] tracking-[-0.05em] sm:text-6xl lg:text-7xl">
    Create addresses that feel{" "}
    <span className="bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
      real.
    </span>
  </h1>

  <p className="max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
    Generate realistic and coherent addresses in seconds—perfect for
    mockups, testing, prototypes, and wherever your imagination takes you.
  </p>

  <div className="pt-2">
    <Link
      href="/docs"
      className="group relative inline-flex items-center gap-2.5 overflow-hidden rounded-full border border-primary/25 bg-primary/[0.07] py-2.5 pl-3 pr-5 text-sm font-semibold text-foreground shadow-lg shadow-primary/10 backdrop-blur-md transition duration-300 hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 focus-visible:ring-offset-background motion-reduce:transition-none motion-reduce:hover:translate-y-0"
    >
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-primary/25 to-transparent transition-transform duration-700 ease-out group-hover:translate-x-full motion-reduce:hidden"
      />

      <span className="relative flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary ring-1 ring-inset ring-primary/25 transition duration-300 group-hover:bg-primary/25">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" aria-hidden="true">
          <path
            d="M2 2.5A1.5 1.5 0 0 1 3.5 1h8A1.5 1.5 0 0 1 13 2.5v10a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 2 12.5v-10Zm1.5-.5a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-10a.5.5 0 0 0-.5-.5h-8ZM4.5 4h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1 0-1Zm0 2.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1 0-1ZM4.5 9h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1 0-1Z"
            fill="currentColor"
            fillRule="evenodd"
            clipRule="evenodd"
          />
        </svg>
      </span>

      <span className="relative">Read the docs</span>

      <svg
        width="14"
        height="14"
        viewBox="0 0 14 14"
        fill="none"
        aria-hidden="true"
        className="relative text-primary transition-transform duration-300 group-hover:translate-x-1 motion-reduce:transition-none motion-reduce:group-hover:translate-x-0"
      >
        <path d="M3 7h8M7.5 3.5 11 7l-3.5 3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </Link>
  </div>
</div>
          </div>

          <AddressGenerator />
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
