import { NextRequest, NextResponse } from 'next/server'

import type { Address } from '@/lib/address'
import { findCountry } from '@/lib/countries'

type NominatimResult = {
  display_name: string
  address?: Record<string, string>
}

const SEARCH_TERMS = ['main street', 'market street', 'station road', 'high street', 'central avenue']

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get('country')?.toUpperCase() ?? ''
  const previous = request.nextUrl.searchParams.get('previous') ?? ''
  const country = findCountry(code)

  if (!country) {
    return NextResponse.json({ error: 'Unknown country code.' }, { status: 400 })
  }

  const start = Math.floor(Math.random() * SEARCH_TERMS.length)

  for (let index = 0; index < SEARCH_TERMS.length; index += 1) {
    const query = SEARCH_TERMS[(start + index) % SEARCH_TERMS.length]
    const params = new URLSearchParams({
      q: query,
      countrycodes: code.toLowerCase(),
      format: 'jsonv2',
      addressdetails: '1',
      limit: '20',
    })

    const response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
      headers: {
        Accept: 'application/json',
        'Accept-Language': 'en',
        'User-Agent': 'ZulzzAddress/1.0',
      },
      cache: 'no-store',
    })

    if (!response.ok) continue

    const results = (await response.json()) as NominatimResult[]
    const candidates = results
      .map((result): Address | null => {
        const item = result.address
        if (!item) return null

        const road = item.road ?? item.pedestrian ?? item.residential ?? item.neighbourhood
        const houseNumber = item.house_number
        const city = item.city ?? item.town ?? item.village ?? item.municipality
        const state = item.state ?? item.region ?? item.county
        const postcode = item.postcode
        const resultCountryCode = item.country_code?.toUpperCase()

        if (!road || !city || !state || !postcode || resultCountryCode !== code) return null

        return {
          street: houseNumber ? `${houseNumber} ${road}` : road,
          city,
          state,
          zip: postcode,
          country: item.country ?? country.name,
          countryCode: country.code,
          flag: country.flag,
        }
      })
      .filter((address): address is Address => address !== null)
      .filter((address) => `${address.street}\n${address.city}, ${address.state} ${address.zip}\n${address.country}` !== previous)

    if (candidates.length > 0) {
      return NextResponse.json(candidates[Math.floor(Math.random() * candidates.length)])
    }
  }

  return NextResponse.json(
    { error: `No complete, verifiable address is currently available for ${country.name}. Try again later.` },
    { status: 404 },
  )
}
