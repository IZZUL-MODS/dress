'use client'

import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Code2, Database, Globe2, Zap } from 'lucide-react'

export default function DocsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex flex-1 flex-col items-center px-4 pb-12 pt-12 sm:px-6 sm:pt-16">
        <div className="w-full max-w-3xl">
          {/* Header */}
          <div className="mb-12 flex flex-col gap-4">
            <div className="inline-flex w-fit items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              ✦ Documentation
            </div>
            <h1 className="text-balance text-4xl font-bold leading-[1.05] tracking-[-0.05em] sm:text-5xl">
              How it works
            </h1>
            <p className="max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
              Discover how our address generator creates realistic, validated addresses across 249 countries using real-world data.
            </p>
          </div>

          {/* Feature cards */}
          <div className="mb-12 grid gap-6 sm:grid-cols-2">
            <div className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Database className="size-5" />
                </div>
                <h3 className="text-lg font-semibold">Real OpenStreetMap Data</h3>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Every address is verified against OpenStreetMap's global database. Streets, cities, states, and postal codes are 100% authentic and geographically accurate.
              </p>
            </div>

            <div className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Globe2 className="size-5" />
                </div>
                <h3 className="text-lg font-semibold">249 Countries</h3>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Support for every country and territory. Select any location and instantly generate coherent addresses with valid regional data.
              </p>
            </div>

            <div className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Zap className="size-5" />
                </div>
                <h3 className="text-lg font-semibold">Instant Generation</h3>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Generate realistic addresses in seconds. Perfect for mockups, testing, prototypes, design presentations, and data sampling.
              </p>
            </div>

            <div className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
              <div className="mb-3 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Code2 className="size-5" />
                </div>
                <h3 className="text-lg font-semibold">Easy to Copy</h3>
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                One-click copy functionality. Get formatted addresses ready to paste into your projects instantly.
              </p>
            </div>
          </div>

          {/* Process section */}
          <div className="mb-12 rounded-2xl border border-border bg-card/50 p-8 backdrop-blur-sm">
            <h2 className="mb-6 text-2xl font-bold">How we verify addresses</h2>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  1
                </div>
                <div>
                  <h3 className="font-semibold">Country Selection</h3>
                  <p className="text-sm text-muted-foreground">Choose from 249 ISO-coded countries with flag icons for easy navigation.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  2
                </div>
                <div>
                  <h3 className="font-semibold">OpenStreetMap Query</h3>
                  <p className="text-sm text-muted-foreground">We search the Nominatim API for verified streets, cities, and postal codes in the selected country.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  3
                </div>
                <div>
                  <h3 className="font-semibold">Validation & Deduplication</h3>
                  <p className="text-sm text-muted-foreground">All fields are validated to ensure geographic coherence. Previous results are never repeated in succession.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  4
                </div>
                <div>
                  <h3 className="font-semibold">Instant Display</h3>
                  <p className="text-sm text-muted-foreground">The formatted address appears with country flag, ready to copy and use in your project.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Data accuracy section */}
          <div className="rounded-2xl border border-border bg-card/50 p-8 backdrop-blur-sm">
            <h2 className="mb-4 text-2xl font-bold">Data Accuracy</h2>
            <p className="mb-4 text-sm text-muted-foreground">
              All addresses are sourced directly from OpenStreetMap (OSM), a free and open-source geographic database maintained by millions of contributors worldwide. Each address is verified to ensure:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex gap-2">
                <span className="text-primary">✓</span>
                <span><strong>Street validity:</strong> Real roads and streets that exist in the selected country</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary">✓</span>
                <span><strong>City coherence:</strong> Streets and cities are geographically matched</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary">✓</span>
                <span><strong>Postal code accuracy:</strong> Valid ZIP/postal codes for the region</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary">✓</span>
                <span><strong>Country confirmation:</strong> Address location verified against selected country</span>
              </li>
            </ul>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
