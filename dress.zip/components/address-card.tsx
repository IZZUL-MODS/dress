import type { GeneratedAddress } from "@/lib/types"

interface AddressCardProps { address: GeneratedAddress }
interface AddressRowProps { label: string; value: string }

function AddressRow({ label, value }: AddressRowProps) {
  return (
    <div className="flex flex-col gap-1 border-b border-border py-3 last:border-b-0 sm:flex-row sm:items-center sm:justify-between">
      <dt className="text-sm font-medium text-muted-foreground">{label}</dt>
      <dd className="font-mono text-sm text-foreground sm:text-right">{value}</dd>
    </div>
  )
}

export function AddressCard({ address }: AddressCardProps) {
  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-lg font-semibold text-card-foreground">Alamat Nyata Terverifikasi</h2>
        <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          <span aria-hidden="true" className="size-1.5 rounded-full bg-primary" />
          Satu titik OSM
        </span>
      </div>

      <dl>
        <AddressRow label="Jalan" value={address.street} />
        <AddressRow label="Kota / Lokalitas" value={address.city} />
        <AddressRow label="State / Provinsi" value={address.state} />
        <AddressRow label="Kode Pos" value={address.zipCode} />
        <AddressRow label="Negara" value={`${address.country} (${address.countryCode})`} />
      </dl>

      <div className="flex flex-col gap-1 border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
        <p>Sumber: {address.dataSource} · objek {address.osmType}/{address.osmId}</p>
        <p>Koordinat: {address.latitude.toFixed(6)}, {address.longitude.toFixed(6)}</p>
        <p>
          {address.isPostalCodeFormatValid === null
            ? "Kode pos tidak tersedia pada titik ini."
            : address.isPostalCodeFormatValid
              ? "Format kode pos cocok dengan negara."
              : "Alamat terverifikasi, tetapi format kode pos tidak dapat dikonfirmasi oleh validator."}
        </p>
      </div>
    </div>
  )
}
