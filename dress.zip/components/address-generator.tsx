"use client"

import { useState } from "react"
import useSWR from "swr"
import { AddressCard } from "@/components/address-card"
import type { ApiError, CountriesResponse, GeneratedAddress } from "@/lib/types"

const fetcher = async (url: string): Promise<CountriesResponse> => {
  const response = await fetch(url)
  if (!response.ok) throw new Error("Daftar negara gagal dimuat.")
  return response.json() as Promise<CountriesResponse>
}

export function AddressGenerator() {
  const { data, error: countriesError, isLoading } = useSWR("/api/countries", fetcher)
  const countryList = data?.countries ?? []
  const [selectedCountry, setSelectedCountry] = useState("US")
  const [address, setAddress] = useState<GeneratedAddress | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const selected = countryList.find((country) => country.code === selectedCountry)

  async function handleGenerate(): Promise<void> {
    setIsGenerating(true)
    setError(null)
    setAddress(null)

    const countryAtRequest = selectedCountry
    const controller = new AbortController()
    const timer = window.setTimeout(() => controller.abort(), 18_000)

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ countryCode: countryAtRequest }),
        signal: controller.signal,
      })
      const result = (await response.json()) as GeneratedAddress | ApiError
      if (!response.ok || "error" in result) {
        throw new Error("error" in result ? result.error : "Alamat gagal dicari.")
      }
      if (countryAtRequest === selectedCountry) setAddress(result)
    } catch (caught) {
      if (countryAtRequest !== selectedCountry) return
      setError(
        caught instanceof DOMException && caught.name === "AbortError"
          ? "Pencarian melewati batas 18 detik karena layanan OpenStreetMap sedang lambat. Silakan coba lagi."
          : caught instanceof Error
            ? caught.message
            : "Alamat gagal dicari.",
      )
    } finally {
      window.clearTimeout(timer)
      if (countryAtRequest === selectedCountry) setIsGenerating(false)
    }
  }

  return (
    <div className="flex w-full flex-col gap-6">
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="country-select" className="text-sm font-medium text-card-foreground">
              Negara atau wilayah
            </label>
            <select
              id="country-select"
              value={selectedCountry}
              onChange={(event) => {
                setSelectedCountry(event.target.value)
                setAddress(null)
                setError(null)
              }}
              disabled={isLoading || Boolean(countriesError)}
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isLoading ? (
                <option>Memuat negara...</option>
              ) : (
                countryList.map((country) => (
                  <option key={country.code} value={country.code}>
                    {country.name} ({country.code}){country.hasAuthenticCoverage ? "" : " — tidak tersedia"}
                  </option>
                ))
              )}
            </select>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {selected?.hasAuthenticCoverage === false
                ? "Wilayah ini tidak memiliki sistem alamat jalan sipil yang dapat diverifikasi."
                : `${countryList.length || 249} wilayah tersedia. Hasil sukses selalu diverifikasi pada satu titik OpenStreetMap.`}
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleGenerate()}
            disabled={isLoading || isGenerating || Boolean(countriesError) || selected?.hasAuthenticCoverage === false}
            className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <span aria-hidden="true" className="size-4 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
                Mencari alamat nyata (maks. 18 detik)...
              </>
            ) : (
              "Cari Alamat Terverifikasi"
            )}
          </button>
        </div>
      </div>

      {(error || countriesError) && (
        <div role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error ?? (countriesError instanceof Error ? countriesError.message : "Daftar negara gagal dimuat.")}
        </div>
      )}

      {address && <AddressCard address={address} />}
    </div>
  )
}
