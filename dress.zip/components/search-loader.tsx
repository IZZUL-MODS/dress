"use client"

import { useEffect, useState } from "react"

const STEPS = [
  "Menghubungi OpenStreetMap...",
  "Memindai titik alamat nyata...",
  "Memvalidasi koordinat tunggal...",
  "Mencocokkan jalan, kota, provinsi...",
  "Menyusun alamat terverifikasi...",
]

export function SearchLoader() {
  const [stepIndex, setStepIndex] = useState(0)

  useEffect(() => {
    const interval = window.setInterval(() => {
      setStepIndex((current) => (current + 1) % STEPS.length)
    }, 2200)
    return () => window.clearInterval(interval)
  }, [])

  return (
    <div
      role="status"
      aria-live="polite"
      className="flex flex-col items-center gap-6 rounded-xl border border-border bg-card p-8 shadow-sm"
    >
      {/* Radar map scanner */}
      <div className="relative flex size-32 items-center justify-center">
        {/* Concentric grid rings */}
        <span className="absolute inset-0 rounded-full border border-border" />
        <span className="absolute inset-4 rounded-full border border-border/70" />
        <span className="absolute inset-8 rounded-full border border-border/50" />

        {/* Cross hair */}
        <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-border/60" />
        <span className="absolute top-1/2 left-0 h-px w-full -translate-y-1/2 bg-border/60" />

        {/* Expanding ping pulses */}
        <span className="absolute size-10 animate-loader-ping rounded-full bg-primary/20" />
        <span
          className="absolute size-10 animate-loader-ping rounded-full bg-primary/20"
          style={{ animationDelay: "1s" }}
        />

        {/* Sweeping radar beam */}
        <span className="absolute inset-0 animate-loader-sweep rounded-full [background:conic-gradient(from_0deg,transparent_0deg,transparent_300deg,var(--color-primary)_360deg)] opacity-25" />

        {/* Dropping pin */}
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="relative size-9 animate-loader-drop text-primary drop-shadow-sm"
          aria-hidden="true"
        >
          <path
            d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11Z"
            fill="currentColor"
            fillOpacity="0.15"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <circle cx="12" cy="10" r="2.5" fill="currentColor" />
        </svg>
      </div>

      <div className="flex flex-col items-center gap-2 text-center">
        <p className="text-sm font-medium text-card-foreground">{STEPS[stepIndex]}</p>

        {/* Step progress dots */}
        <div className="flex items-center gap-1.5" aria-hidden="true">
          {STEPS.map((step, index) => (
            <span
              key={step}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                index === stepIndex ? "w-6 bg-primary" : "w-1.5 bg-border"
              }`}
            />
          ))}
        </div>

        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">Maksimal 18 detik. Data 100% dari OpenStreetMap.</p>
      </div>
    </div>
  )
}
