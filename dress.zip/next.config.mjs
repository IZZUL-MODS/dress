/** @type {import('next').NextConfig} */
const nextConfig = {
  // These packages load data files at runtime and must not be bundled
  serverExternalPackages: [
    'postal-codes-js',
    'i18n-iso-countries',
    'country-state-city',
  ],
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
