// ISO territories with no permanent civilian street-address system or
// no usable OpenStreetMap address-road coverage. They remain valid ISO
// entries but are intentionally excluded rather than represented with
// synthetic data.
const WITHOUT_STREET_ADDRESS_COVERAGE = new Set([
  "AQ", // Antarctica
  "BV", // Bouvet Island
  "HM", // Heard Island and McDonald Islands
  "TF", // French Southern Territories
  "UM", // United States Minor Outlying Islands
])

export function supportsAuthenticAddresses(countryCode: string): boolean {
  return !WITHOUT_STREET_ADDRESS_COVERAGE.has(countryCode.toUpperCase())
}
