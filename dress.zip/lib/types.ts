export interface Country {
  code: string
  name: string
  hasAuthenticCoverage: boolean
}

export interface CountriesResponse {
  countries: Country[]
}

export interface GenerateRequestBody {
  countryCode: string
}

export interface GeneratedAddress {
  street: string
  city: string
  state: string
  zipCode: string
  country: string
  countryCode: string
  isPostalCodeFormatValid: boolean | null
  verified: true
  dataSource: "OpenStreetMap"
  latitude: number
  longitude: number
  osmType: string
  osmId: number
}

export type ApiErrorCode =
  | "INVALID_REQUEST"
  | "UNKNOWN_COUNTRY"
  | "NO_CIVILIAN_ADDRESS_SYSTEM"
  | "ADDRESS_NOT_FOUND"
  | "UPSTREAM_UNAVAILABLE"

export interface ApiError {
  error: string
  code: ApiErrorCode
  retryable: boolean
}
