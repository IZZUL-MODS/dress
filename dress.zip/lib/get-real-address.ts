import { City, Country, State } from "country-state-city"

const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
]
const NOMINATIM_ENDPOINT = "https://nominatim.openstreetmap.org/reverse"
const USER_AGENT = "VerifiedGlobalAddress/3.0 (https://github.com/IZZUL-MODS/dress)"
const RESULT_TTL = 6 * 60 * 60 * 1000
const REVERSE_TTL = 24 * 60 * 60 * 1000
const MAX_CACHE_ITEMS = 500
// Hard budget for the whole server-side search. When it elapses we abort every
// in-flight network call instead of just resolving a deadline promise.
const SEARCH_BUDGET_MS = 14_000
const OVERPASS_TIMEOUT_MS = 5_000
const NOMINATIM_TIMEOUT_MS = 6_000

export interface RealAddress {
  street: string
  city: string
  state: string
  zipCode: string
  latitude: number
  longitude: number
  osmType: string
  osmId: number
}

export type AddressResolution =
  | { status: "success"; address: RealAddress }
  | { status: "not_found" }
  | { status: "upstream_unavailable" }

interface Anchor { latitude: number; longitude: number }
interface OverpassElement {
  type: "node" | "way" | "relation"
  id: number
  lat?: number
  lon?: number
  center?: { lat: number; lon: number }
  tags?: Record<string, string | undefined>
}
interface CacheItem<T> { value: T; expiresAt: number }

const resultCache = new Map<string, CacheItem<RealAddress>>()
const reverseCache = new Map<string, CacheItem<RealAddress | null>>()
const pendingByCountry = new Map<string, Promise<AddressResolution>>()
let nextNominatimRequestAt = 0

function readCache<T>(cache: Map<string, CacheItem<T>>, key: string): T | undefined {
  const item = cache.get(key)
  if (!item) return undefined
  if (item.expiresAt <= Date.now()) {
    cache.delete(key)
    return undefined
  }
  return item.value
}

function writeCache<T>(cache: Map<string, CacheItem<T>>, key: string, value: T, ttl: number) {
  if (cache.size >= MAX_CACHE_ITEMS) cache.delete(cache.keys().next().value as string)
  cache.set(key, { value, expiresAt: Date.now() + ttl })
}

function finiteCoordinate(value: string | null | undefined): number | null {
  if (!value) return null
  const parsed = Number.parseFloat(value)
  return Number.isFinite(parsed) ? parsed : null
}

function getAnchors(countryCode: string): Anchor[] {
  const anchors: Anchor[] = []
  const seen = new Set<string>()
  const add = (latitude: number | null, longitude: number | null) => {
    if (latitude === null || longitude === null) return
    if (Math.abs(latitude) > 90 || Math.abs(longitude) > 180) return
    const key = `${latitude.toFixed(3)},${longitude.toFixed(3)}`
    if (!seen.has(key)) {
      seen.add(key)
      anchors.push({ latitude, longitude })
    }
  }

  const states = State.getStatesOfCountry(countryCode) ?? []
  const statePool = [...states].sort(() => Math.random() - 0.5)
  for (const state of statePool) {
    const cities = City.getCitiesOfState(countryCode, state.isoCode) ?? []
    const cityPool = cities.filter((city) => city.latitude && city.longitude)
    if (cityPool.length) {
      const city = cityPool[Math.floor(Math.random() * cityPool.length)]
      add(finiteCoordinate(city.latitude), finiteCoordinate(city.longitude))
    }
    if (anchors.length >= 2) break
  }

  const country = Country.getCountryByCode(countryCode)
  add(finiteCoordinate(country?.latitude), finiteCoordinate(country?.longitude))
  // At most two anchors keeps the number of Overpass round-trips small.
  return anchors.slice(0, 2)
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number,
  parentSignal: AbortSignal,
) {
  const controller = new AbortController()
  const onAbort = () => controller.abort()
  parentSignal.addEventListener("abort", onAbort, { once: true })
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    return await fetch(url, { ...init, signal: controller.signal })
  } finally {
    clearTimeout(timer)
    parentSignal.removeEventListener("abort", onAbort)
  }
}

async function queryOverpass(anchor: Anchor, radius: number, signal: AbortSignal) {
  // Require BOTH street and house number so returned objects are complete and
  // the payload stays small, which makes reverse lookups succeed faster.
  const query = `[out:json][timeout:6];(node["addr:street"]["addr:housenumber"](around:${radius},${anchor.latitude},${anchor.longitude});way["addr:street"]["addr:housenumber"](around:${radius},${anchor.latitude},${anchor.longitude}););out center tags 30;`
  let reachedUpstream = false

  for (let attempt = 0; attempt < OVERPASS_ENDPOINTS.length; attempt += 1) {
    if (signal.aborted) break
    try {
      const response = await fetchWithTimeout(
        OVERPASS_ENDPOINTS[attempt],
        {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": USER_AGENT },
          body: `data=${encodeURIComponent(query)}`,
          cache: "no-store",
        },
        OVERPASS_TIMEOUT_MS,
        signal,
      )
      if (response.status === 429 || response.status >= 500) continue
      if (!response.ok) continue
      reachedUpstream = true
      const data = (await response.json()) as { elements?: OverpassElement[] }
      return { elements: data.elements ?? [], reachedUpstream }
    } catch {
      // Move straight to the fallback endpoint; no slow backoff inside the budget.
      if (signal.aborted) break
    }
  }
  return { elements: [] as OverpassElement[], reachedUpstream }
}

function first(address: Record<string, string | undefined>, keys: string[]) {
  for (const key of keys) {
    const value = address[key]?.trim()
    if (value) return value
  }
  return null
}

async function respectNominatimLimit(signal: AbortSignal) {
  const wait = Math.max(0, nextNominatimRequestAt - Date.now())
  if (wait) await new Promise((resolve) => setTimeout(resolve, Math.min(wait, 1100)))
  nextNominatimRequestAt = Date.now() + 1100
  if (signal.aborted) throw new Error("aborted")
}

async function reverseCandidate(element: OverpassElement, countryCode: string, signal: AbortSignal) {
  const latitude = element.lat ?? element.center?.lat
  const longitude = element.lon ?? element.center?.lon
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return { address: null, reachedUpstream: true }

  const key = `${latitude!.toFixed(6)},${longitude!.toFixed(6)},${countryCode}`
  const cached = readCache(reverseCache, key)
  if (cached !== undefined) return { address: cached, reachedUpstream: true }

  await respectNominatimLimit(signal)
  const url = new URL(NOMINATIM_ENDPOINT)
  url.searchParams.set("lat", String(latitude))
  url.searchParams.set("lon", String(longitude))
  url.searchParams.set("format", "jsonv2")
  url.searchParams.set("addressdetails", "1")
  url.searchParams.set("zoom", "18")
  url.searchParams.set("accept-language", "en")

  try {
    const response = await fetchWithTimeout(
      url.toString(),
      { headers: { "User-Agent": USER_AGENT, Accept: "application/json" }, cache: "no-store" },
      NOMINATIM_TIMEOUT_MS,
      signal,
    )
    if (!response.ok) return { address: null, reachedUpstream: false }
    const data = (await response.json()) as {
      osm_type?: string
      osm_id?: number
      address?: Record<string, string | undefined>
    }
    const raw = data.address
    if (!raw || raw.country_code?.toUpperCase() !== countryCode) {
      writeCache(reverseCache, key, null, REVERSE_TTL)
      return { address: null, reachedUpstream: true }
    }

    const road = first(raw, ["road", "pedestrian", "residential", "footway", "path", "square", "place"])
    const city = first(raw, ["city", "town", "village", "municipality", "hamlet", "city_district", "county"])
    const state = first(raw, ["state", "province", "region", "state_district", "county", "municipality"])
    if (!road || !city || !state) {
      writeCache(reverseCache, key, null, REVERSE_TTL)
      return { address: null, reachedUpstream: true }
    }

    const houseNumber = raw.house_number?.trim()
    const address: RealAddress = {
      street: houseNumber ? `${houseNumber} ${road}` : road,
      city,
      state,
      zipCode: raw.postcode?.trim() ?? "",
      latitude: latitude!,
      longitude: longitude!,
      osmType: data.osm_type ?? element.type,
      osmId: data.osm_id ?? element.id,
    }
    writeCache(reverseCache, key, address, REVERSE_TTL)
    return { address, reachedUpstream: true }
  } catch {
    return { address: null, reachedUpstream: false }
  }
}

async function resolveAddress(countryCode: string, signal: AbortSignal): Promise<AddressResolution> {
  const cached = readCache(resultCache, countryCode)
  if (cached) return { status: "success", address: cached }

  const anchors = getAnchors(countryCode)
  if (!anchors.length) return { status: "not_found" }
  let anyUpstreamReached = false

  for (const anchor of anchors) {
    if (signal.aborted) break
    // A single mid-size radius per anchor is enough for populated areas and
    // avoids a second expensive Overpass pass.
    const overpass = await queryOverpass(anchor, 6_000, signal)
    anyUpstreamReached ||= overpass.reachedUpstream
    const candidates = [...overpass.elements]
      .filter((item) => item.tags?.["addr:street"])
      .slice(0, 2)

    for (const candidate of candidates) {
      if (signal.aborted) break
      const reverse = await reverseCandidate(candidate, countryCode, signal)
      anyUpstreamReached ||= reverse.reachedUpstream
      if (reverse.address) {
        writeCache(resultCache, countryCode, reverse.address, RESULT_TTL)
        return { status: "success", address: reverse.address }
      }
    }
  }

  if (signal.aborted && !anyUpstreamReached) return { status: "upstream_unavailable" }
  return { status: anyUpstreamReached ? "not_found" : "upstream_unavailable" }
}

export function getRealAddress(countryCode: string): Promise<AddressResolution> {
  const code = countryCode.toUpperCase()
  const pending = pendingByCountry.get(code)
  if (pending) return pending

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), SEARCH_BUDGET_MS)

  const request = resolveAddress(code, controller.signal)
    .catch(() => ({ status: "upstream_unavailable" }) as AddressResolution)
    .finally(() => {
      clearTimeout(timer)
      pendingByCountry.delete(code)
    })

  pendingByCountry.set(code, request)
  return request
}
