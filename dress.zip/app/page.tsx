import { AddressGenerator } from "@/components/address-generator"

export default function HomePage() {
  return (
    <main className="flex min-h-svh flex-col items-center bg-background px-4 py-12 sm:py-20">
      <div className="w-full max-w-xl">
        <header className="mb-10 text-center">
          <p className="mb-3 inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            OpenStreetMap &middot; 249 wilayah ISO
          </p>
          <h1 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Pencari Alamat Nyata
          </h1>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            Temukan jalan, kota, provinsi, dan negara yang cocok dari satu titik OpenStreetMap yang sama.
          </p>
        </header>

        <AddressGenerator />

        <footer className="mt-10 text-center text-xs leading-relaxed text-muted-foreground">
          Tidak ada fallback sintetis. Wilayah tanpa alamat sipil atau data terverifikasi akan ditandai secara jujur.
        </footer>
      </div>
    </main>
  )
}
