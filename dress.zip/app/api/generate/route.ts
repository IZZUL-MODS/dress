import { NextResponse } from "next/server"
import countries from "i18n-iso-countries"
import enLocale from "i18n-iso-countries/langs/en.json"
import postalCodes from "postal-codes-js"
import { getRealAddress } from "@/lib/get-real-address"
import { supportsAuthenticAddresses } from "@/lib/supported-countries"
import type { ApiError, GeneratedAddress, GenerateRequestBody } from "@/lib/types"

countries.registerLocale(enLocale)
export const maxDuration = 60

function isGenerateRequestBody(body: unknown): body is GenerateRequestBody {
  return (
    typeof body === "object" &&
    body !== null &&
    "countryCode" in body &&
    typeof (body as Record<string, unknown>).countryCode === "string"
  )
}

function errorResponse(error: string, code: ApiError["code"], retryable: boolean, status: number) {
  return NextResponse.json<ApiError>({ error, code, retryable }, { status })
}

export async function POST(request: Request): Promise<NextResponse<GeneratedAddress | ApiError>> {
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return errorResponse("Body JSON tidak valid.", "INVALID_REQUEST", false, 400)
  }

  if (!isGenerateRequestBody(body)) {
    return errorResponse("Pilih kode negara yang valid.", "INVALID_REQUEST", false, 400)
  }

  const countryCode = body.countryCode.trim().toUpperCase()
  const countryName = countries.getName(countryCode, "en")
  if (!countryName || countryCode === "XK") {
    return errorResponse(`Kode negara tidak dikenal: ${countryCode}`, "UNKNOWN_COUNTRY", false, 400)
  }

  if (!supportsAuthenticAddresses(countryCode)) {
    return errorResponse(
      "Wilayah ini tidak memiliki sistem alamat jalan sipil nyata yang dapat diverifikasi.",
      "NO_CIVILIAN_ADDRESS_SYSTEM",
      false,
      422,
    )
  }

  const resolution = await getRealAddress(countryCode)
  if (resolution.status === "upstream_unavailable") {
    return errorResponse(
      "Layanan OpenStreetMap sedang sibuk atau tidak tersedia. Silakan coba lagi.",
      "UPSTREAM_UNAVAILABLE",
      true,
      503,
    )
  }
  if (resolution.status === "not_found") {
    return errorResponse(
      "Belum ditemukan alamat jalan nyata yang lengkap untuk wilayah ini. Coba lagi untuk mencari area lain.",
      "ADDRESS_NOT_FOUND",
      true,
      404,
    )
  }

  const realAddress = resolution.address
  const postalValidation = realAddress.zipCode
    ? postalCodes.validate(countryCode, realAddress.zipCode)
    : null

  return NextResponse.json({
    ...realAddress,
    zipCode: realAddress.zipCode || "Tidak tersedia",
    country: countryName,
    countryCode,
    isPostalCodeFormatValid: postalValidation === null ? null : postalValidation === true,
    verified: true,
    dataSource: "OpenStreetMap",
  })
}
