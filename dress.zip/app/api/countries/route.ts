import { NextResponse } from "next/server"
import countries from "i18n-iso-countries"
import enLocale from "i18n-iso-countries/langs/en.json"
import { supportsAuthenticAddresses } from "@/lib/supported-countries"
import type { CountriesResponse, Country } from "@/lib/types"

countries.registerLocale(enLocale)

export async function GET(): Promise<NextResponse<CountriesResponse>> {
  const names = countries.getNames("en", { select: "official" })
  const list: Country[] = Object.entries(names)
    .filter(([code]) => code !== "XK")
    .map(([code, name]) => ({
      code,
      name,
      hasAuthenticCoverage: supportsAuthenticAddresses(code),
    }))
    .sort((a, b) => a.name.localeCompare(b.name))

  return NextResponse.json({ countries: list })
}
