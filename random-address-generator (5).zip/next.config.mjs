/** @type {import('next').NextConfig} */
const nextConfig = {
  // postal-codes-js loads its per-country JSON format files via dynamic
  // require() at runtime, so it must not be bundled by Turbopack/Webpack.
  serverExternalPackages: ['postal-codes-js'],
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
