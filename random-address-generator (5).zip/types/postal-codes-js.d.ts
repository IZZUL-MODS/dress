declare module "postal-codes-js" {
  /**
   * Validates a postal code for a given country.
   * Returns `true` when valid, otherwise an error message string.
   */
  export function validate(countryCode: string, postalCode: string | number): true | string
}
