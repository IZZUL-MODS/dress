import { NextResponse } from "next/server"
import postalCodes from "postal-codes-js"
import countries from "i18n-iso-countries"
import enLocale from "i18n-iso-countries/langs/en.json"
import { resolveFakerForCountry } from "@/lib/faker-locale"
import { getRandomCityState } from "@/lib/get-city-state"
import { generateStreetForCity } from "@/lib/generate-street"
import type { ApiError, GeneratedAddress, GenerateRequestBody } from "@/lib/types"

countries.registerLocale(enLocale)

function isGenerateRequestBody(body: unknown): body is GenerateRequestBody {
  return (
    typeof body === "object" &&
    body !== null &&
    "countryCode" in body &&
    typeof (body as Record<string, unknown>).countryCode === "string"
  )
}

export async function POST(request: Request): Promise<NextResponse<GeneratedAddress | ApiError>> {
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 })
  }

  if (!isGenerateRequestBody(body)) {
    return NextResponse.json({ error: "Missing or invalid 'countryCode' field" }, { status: 400 })
  }

  const countryCode = body.countryCode.toUpperCase()
  const countryName = countries.getName(countryCode, "en")

  if (!countryName) {
    return NextResponse.json({ error: `Unknown country code: ${countryCode}` }, { status: 400 })
  }

  const { faker, localeKey } = resolveFakerForCountry(countryCode)

  // Some faker locales are missing specific location definitions,
  // so every field falls back safely to the default English faker.
  const safeGenerate = (generate: () => string, fallback: () => string): string => {
    try {
      return generate()
    } catch {
      return fallback()
    }
  }

  const { faker: fallbackFaker } = resolveFakerForCountry("US")

  // Get valid city-state pair from geographic database first
  let city = ""
  let state = ""

  const cityStateData = getRandomCityState(countryCode)
  if (cityStateData) {
    // Use accurate geographic data
    city = cityStateData.city
    state = cityStateData.state
  } else {
    // Fallback: use faker for countries without detailed state data
    city = safeGenerate(
      () => faker.location.city(),
      () => fallbackFaker.location.city(),
    )
    state = safeGenerate(
      () => faker.location.state(),
      () => fallbackFaker.location.state(),
    )
  }

  // Generate street address that's contextually related to the city
  const street = generateStreetForCity(countryCode, city)

  const zipCode = safeGenerate(
    () => faker.location.zipCode(),
    () => fallbackFaker.location.zipCode(),
  )

  // postal-codes-js returns `true` when valid, otherwise an error string
  const validationResult = postalCodes.validate(countryCode, zipCode)
  const isValid = validationResult === true

  const address: GeneratedAddress = {
    street,
    city,
    state,
    zipCode,
    country: countryName,
    countryCode,
    isValid,
    fakerLocale: localeKey,
  }

  return NextResponse.json(address)
}
