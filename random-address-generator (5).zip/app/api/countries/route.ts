import { NextResponse } from "next/server"
import countries from "i18n-iso-countries"
import enLocale from "i18n-iso-countries/langs/en.json"
import type { CountriesResponse, Country } from "@/lib/types"

countries.registerLocale(enLocale)

export async function GET(): Promise<NextResponse<CountriesResponse>> {
  const names = countries.getNames("en", { select: "official" })

  // Exclude "XK" (Kosovo) — a user-assigned code, not one of the
  // 249 officially assigned ISO 3166-1 Alpha-2 codes.
  const list: Country[] = Object.entries(names)
    .filter(([code]) => code !== "XK")
    .map(([code, name]) => ({ code, name }))
    .sort((a, b) => a.name.localeCompare(b.name))

  return NextResponse.json({ countries: list })
}
