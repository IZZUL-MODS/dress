import { AddressGenerator } from "@/components/address-generator"

export default function HomePage() {
  return (
    <main className="flex min-h-svh flex-col items-center bg-background px-4 py-12 sm:py-20">
      <div className="w-full max-w-xl">
        <header className="mb-10 text-center">
          <p className="mb-3 inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            Free &middot; 249 countries supported
          </p>
          <h1 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Random Address Generator
          </h1>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            Generate realistic street addresses for any country in the world, complete with postal code format
            validation.
          </p>
        </header>

        <AddressGenerator />

        <footer className="mt-10 text-center text-xs text-muted-foreground">
          Addresses are randomly generated for testing purposes and do not correspond to real locations.
        </footer>
      </div>
    </main>
  )
}
