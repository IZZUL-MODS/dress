export interface Country {
  code: string
  name: string
}

export interface CountriesResponse {
  countries: Country[]
}

export interface GenerateRequestBody {
  countryCode: string
}

export interface GeneratedAddress {
  street: string
  city: string
  state: string
  zipCode: string
  country: string
  countryCode: string
  isValid: boolean
  fakerLocale: string
}

export interface ApiError {
  error: string
}
