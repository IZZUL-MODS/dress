import { allFakers, faker as defaultFaker, type Faker } from "@faker-js/faker"

type FakerLocaleKey = keyof typeof allFakers

/**
 * Manual overrides for countries whose faker locale key is a plain
 * language code (or otherwise cannot be derived from the country code).
 */
const MANUAL_LOCALE_MAP: Readonly<Record<string, FakerLocaleKey>> = {
  US: "en_US",
  GB: "en_GB",
  AU: "en_AU",
  CA: "en_CA",
  IE: "en_IE",
  IN: "en_IN",
  NG: "en_NG",
  ZA: "en_ZA",
  GH: "en_GH",
  HK: "en_HK",
  DE: "de",
  AT: "de_AT",
  CH: "de_CH",
  FR: "fr",
  BE: "fr_BE",
  LU: "fr_LU",
  SN: "fr_SN",
  ES: "es",
  MX: "es_MX",
  IT: "it",
  PT: "pt_PT",
  BR: "pt_BR",
  NL: "nl",
  DK: "da",
  SE: "sv",
  NO: "nb_NO",
  FI: "fi",
  GR: "el",
  PL: "pl",
  CZ: "cs_CZ",
  SK: "sk",
  HU: "hu",
  RO: "ro",
  MD: "ro_MD",
  HR: "hr",
  RS: "sr_RS_latin",
  UA: "uk",
  RU: "ru",
  TR: "tr",
  AZ: "az",
  AM: "hy",
  GE: "ka_GE",
  IR: "fa",
  AF: "fa",
  MV: "dv",
  PK: "ur",
  BD: "bn_BD",
  NP: "ne",
  TH: "th",
  VN: "vi",
  ID: "id_ID",
  CN: "zh_CN",
  TW: "zh_TW",
  JP: "ja",
  KR: "ko",
  IL: "he",
  SA: "ar",
  AE: "ar",
  EG: "ar",
  JO: "ar",
  LV: "lv",
  SI: "sl_SI",
  MK: "mk",
  MN: "mn_MN_cyrl",
  IQ: "ku_ckb",
  UZ: "uz_UZ_latin",
  LK: "ta_IN",
}

const LOCALE_KEYS = Object.keys(allFakers) as FakerLocaleKey[]

export interface ResolvedFaker {
  faker: Faker
  localeKey: string
}

/**
 * Resolves the best matching Faker instance for an ISO Alpha-2 country code.
 * Falls back safely to the default (English) faker when no locale exists.
 */
export function resolveFakerForCountry(countryCode: string): ResolvedFaker {
  const cc = countryCode.toUpperCase()

  // 1. Manual override map (language-code based locales)
  const manual = MANUAL_LOCALE_MAP[cc]
  if (manual && manual in allFakers) {
    return { faker: allFakers[manual], localeKey: manual }
  }

  // 2. Locale keys ending with the country code, e.g. "de_AT" for AT
  const suffixMatch = LOCALE_KEYS.find((key) => key.endsWith(`_${cc}`))
  if (suffixMatch) {
    return { faker: allFakers[suffixMatch], localeKey: suffixMatch }
  }

  // 3. Locale key equal to the lowercased country code, e.g. "hr" for HR
  const directMatch = LOCALE_KEYS.find((key) => key.toLowerCase() === cc.toLowerCase())
  if (directMatch) {
    return { faker: allFakers[directMatch], localeKey: directMatch }
  }

  // 4. Safe fallback to default English faker
  return { faker: defaultFaker, localeKey: "en" }
}
