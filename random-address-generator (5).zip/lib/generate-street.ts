/**
 * Generate realistic street addresses that are contextually relevant to the city.
 * Since comprehensive street-level geographic databases don't exist for all countries,
 * we use a hybrid approach: combine city name components with locale-specific street types
 * to create plausible street addresses that "feel" connected to the city.
 */

type StreetType = {
  name: string
  abbr?: string
  format: (prefix: string, number: string) => string
}

const STREET_TYPES_BY_COUNTRY: Record<string, StreetType[]> = {
  // Indonesia
  ID: [
    { name: "Jalan", abbr: "Jl.", format: (p, n) => `Jl. ${p} no ${n}` },
    { name: "Jalan Raja", abbr: "Jr.", format: (p, n) => `Jr. ${p} no ${n}` },
    { name: "Jalan Besar", abbr: "Jb.", format: (p, n) => `Jb. ${p} no ${n}` },
    { name: "Jalan Kecil", abbr: "Jk.", format: (p, n) => `Jk. ${p} no ${n}` },
    { name: "Gang", abbr: "Gg.", format: (p, n) => `Gg. ${p} no ${n}` },
    { name: "Pasar", abbr: "Psr.", format: (p, n) => `Psr. ${p} no ${n}` },
  ],
  
  // United States
  US: [
    { name: "Street", abbr: "St", format: (p, n) => `${n} ${p} St` },
    { name: "Avenue", abbr: "Ave", format: (p, n) => `${n} ${p} Ave` },
    { name: "Road", abbr: "Rd", format: (p, n) => `${n} ${p} Rd` },
    { name: "Drive", abbr: "Dr", format: (p, n) => `${n} ${p} Dr` },
    { name: "Lane", abbr: "Ln", format: (p, n) => `${n} ${p} Ln` },
    { name: "Boulevard", abbr: "Blvd", format: (p, n) => `${n} ${p} Blvd` },
    { name: "Court", abbr: "Ct", format: (p, n) => `${n} ${p} Ct` },
    { name: "Trail", abbr: "Trl", format: (p, n) => `${n} ${p} Trl` },
  ],
  
  // Japan
  JP: [
    { name: "丁目", format: (p, n) => `${n}丁目1番${p}号` },
    { name: "番地", format: (p, n) => `${p}番地${n}` },
    { name: "通り", format: (p, n) => `${p}通り${n}丁目` },
  ],
  
  // Brazil
  BR: [
    { name: "Rua", format: (p, n) => `Rua ${p} ${n}` },
    { name: "Avenida", format: (p, n) => `Av. ${p} ${n}` },
    { name: "Travessa", format: (p, n) => `Trav. ${p} ${n}` },
    { name: "Rodovia", format: (p, n) => `Rod. ${p} ${n}` },
    { name: "Praia", format: (p, n) => `Praia ${p} ${n}` },
  ],
  
  // Germany
  DE: [
    { name: "Straße", abbr: "str", format: (p, n) => `${p}str. ${n}` },
    { name: "Allee", format: (p, n) => `${p}allee ${n}` },
    { name: "Weg", format: (p, n) => `${p}weg ${n}` },
    { name: "Platz", format: (p, n) => `${p}platz ${n}` },
  ],
  
  // France
  FR: [
    { name: "Rue", format: (p, n) => `Rue ${p} ${n}` },
    { name: "Avenue", format: (p, n) => `Avenue ${p} ${n}` },
    { name: "Boulevard", format: (p, n) => `Boulevard ${p} ${n}` },
    { name: "Chemin", format: (p, n) => `Chemin ${p} ${n}` },
    { name: "Place", format: (p, n) => `Place ${p} ${n}` },
  ],
  
  // Spain
  ES: [
    { name: "Calle", format: (p, n) => `Calle ${p} ${n}` },
    { name: "Avenida", format: (p, n) => `Avenida ${p} ${n}` },
    { name: "Paseo", format: (p, n) => `Paseo ${p} ${n}` },
    { name: "Plaza", format: (p, n) => `Plaza ${p} ${n}` },
  ],
  
  // United Kingdom
  GB: [
    { name: "Street", format: (p, n) => `${n} ${p} Street` },
    { name: "Road", format: (p, n) => `${n} ${p} Road` },
    { name: "Avenue", format: (p, n) => `${n} ${p} Avenue` },
    { name: "Lane", format: (p, n) => `${n} ${p} Lane` },
  ],
}

/**
 * Extract meaningful prefix from city name.
 * E.g., "New York" -> "York", "San Francisco" -> "Francisco"
 */
function getStreetPrefixFromCity(cityName: string): string {
  const parts = cityName.split(" ")
  
  // If city has multiple words, use the last meaningful one
  if (parts.length > 1) {
    const lastPart = parts[parts.length - 1]
    // Skip common suffixes
    if (!["District", "Province", "Region", "State", "County"].includes(lastPart)) {
      return lastPart
    }
    // Otherwise use second-to-last part
    return parts[parts.length - 2] || parts[0]
  }
  
  // Single word city - use it as prefix
  return parts[0]
}

/**
 * Generate a street address that feels contextually connected to the city.
 */
export function generateStreetForCity(
  countryCode: string,
  cityName: string,
): string {
  const streetTypes = STREET_TYPES_BY_COUNTRY[countryCode] || STREET_TYPES_BY_COUNTRY.US
  
  if (!streetTypes || streetTypes.length === 0) {
    return `${Math.floor(Math.random() * 10000)} Main Street`
  }
  
  // Pick random street type for this country
  const streetType = streetTypes[Math.floor(Math.random() * streetTypes.length)]
  
  // Get a meaningful prefix from city name
  const prefix = getStreetPrefixFromCity(cityName)
  
  // Generate random street number
  const streetNumber = String(Math.floor(Math.random() * 10000) + 1)
  
  // Use the country-specific format
  return streetType.format(prefix, streetNumber)
}
