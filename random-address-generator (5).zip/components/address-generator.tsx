"use client"

import { useEffect, useState } from "react"
import { AddressCard } from "@/components/address-card"
import type { ApiError, CountriesResponse, Country, GeneratedAddress } from "@/lib/types"

export function AddressGenerator() {
  const [countryList, setCountryList] = useState<Country[]>([])
  const [selectedCountry, setSelectedCountry] = useState<string>("US")
  const [address, setAddress] = useState<GeneratedAddress | null>(null)
  const [isLoadingCountries, setIsLoadingCountries] = useState<boolean>(true)
  const [isGenerating, setIsGenerating] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false

    async function fetchCountries(): Promise<void> {
      try {
        const response = await fetch("/api/countries")
        if (!response.ok) {
          throw new Error(`Failed to load countries (${response.status})`)
        }
        const data: CountriesResponse = await response.json()
        if (!cancelled) {
          setCountryList(data.countries)
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Failed to load countries")
        }
      } finally {
        if (!cancelled) {
          setIsLoadingCountries(false)
        }
      }
    }

    void fetchCountries()

    return () => {
      cancelled = true
    }
  }, [])

  async function handleGenerate(): Promise<void> {
    setIsGenerating(true)
    setError(null)

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ countryCode: selectedCountry }),
      })

      const data: GeneratedAddress | ApiError = await response.json()

      if (!response.ok || "error" in data) {
        throw new Error("error" in data ? data.error : "Failed to generate address")
      }

      setAddress(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate address")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="flex w-full flex-col gap-6">
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="country-select" className="text-sm font-medium text-card-foreground">
              Country
            </label>
            <select
              id="country-select"
              value={selectedCountry}
              onChange={(event) => setSelectedCountry(event.target.value)}
              disabled={isLoadingCountries}
              className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isLoadingCountries ? (
                <option>Loading countries…</option>
              ) : (
                countryList.map((country) => (
                  <option key={country.code} value={country.code}>
                    {country.name} ({country.code})
                  </option>
                ))
              )}
            </select>
            {!isLoadingCountries && countryList.length > 0 && (
              <p className="text-xs text-muted-foreground">{countryList.length} countries available</p>
            )}
          </div>

          <button
            type="button"
            onClick={() => void handleGenerate()}
            disabled={isLoadingCountries || isGenerating}
            className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <span
                  aria-hidden="true"
                  className="size-4 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground"
                />
                Generating…
              </>
            ) : (
              "Generate Address"
            )}
          </button>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive"
        >
          {error}
        </div>
      )}

      {address && <AddressCard address={address} />}
    </div>
  )
}
