import type { GeneratedAddress } from "@/lib/types"

interface AddressCardProps {
  address: GeneratedAddress
}

interface AddressRowProps {
  label: string
  value: string
}

function AddressRow({ label, value }: AddressRowProps) {
  return (
    <div className="flex flex-col gap-1 border-b border-border py-3 last:border-b-0 sm:flex-row sm:items-center sm:justify-between">
      <dt className="text-sm font-medium text-muted-foreground">{label}</dt>
      <dd className="font-mono text-sm text-foreground sm:text-right">{value}</dd>
    </div>
  )
}

export function AddressCard({ address }: AddressCardProps) {
  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-card-foreground">Generated Address</h2>
        {address.isValid ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            <span aria-hidden="true" className="size-1.5 rounded-full bg-emerald-500" />
            Valid Postal Code
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-950 dark:text-amber-300">
            <span aria-hidden="true" className="size-1.5 rounded-full bg-amber-500" />
            Unverified Format
          </span>
        )}
      </div>

      <dl>
        <AddressRow label="Street" value={address.street} />
        <AddressRow label="City" value={address.city} />
        <AddressRow label="State / Province" value={address.state} />
        <AddressRow label="Zip Code" value={address.zipCode} />
        <AddressRow label="Country" value={`${address.country} (${address.countryCode})`} />
      </dl>

      <p className="mt-4 text-xs text-muted-foreground">
        Locale used: <span className="font-mono">{address.fakerLocale}</span>
      </p>
    </div>
  )
}
